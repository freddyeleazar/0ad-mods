function WeatherEffects() {}

WeatherEffects.prototype.Schema =
	"<a:component type='system'/><empty/>";

var INTENSITY_CURVES = {
	"rain":        [0.15, 0.12, 0.05, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.03, 0.08, 0.12],
	"cherry":      [0.0,  0.0,  0.0,  0.8,  1.0,  0.3,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0],
	"fireflies":   [0.0,  0.0,  0.0,  0.0,  0.0,  0.3,  0.8,  1.0,  0.5,  0.0,  0.0,  0.0]
};

var PRIMARY_VARIANTS = {
	"rain": [
		{ "threshold": 0.01, "template": "special/weather_rain" }
	]
};

var BIOME_FACTORS = {
	"rain":      { "arctic": 0.5, "sahara": 0.0, "temperate": 1.0 },
	"cherry":    { "arctic": 0.0, "sahara": 0.0, "temperate": 1.0 },
	"fireflies": { "arctic": 0.5, "sahara": 0.5, "temperate": 1.0 }
};

var SOUND_MAP = {
	"special/weather_rain": 0
};

WeatherEffects.prototype.Init = function()
{
	this.weatherEntities = [];
	this.currentWeather = -1;
	this.biome = "temperate";
	this.debugMonth = undefined;
	this.activeSlots = {};

	var weatherInterval = 60000;
	var cmpDNC = Engine.QueryInterface(SYSTEM_ENTITY, IID_DayNightCycle);
	if (cmpDNC)
		weatherInterval = Math.round(cmpDNC.GetCycleDuration() * 1000 / 8);

	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	cmpTimer.SetTimeout(SYSTEM_ENTITY, IID_WeatherEffects, "updateWeather", 5000, null);
	cmpTimer.SetInterval(SYSTEM_ENTITY, IID_WeatherEffects, "updateWeather", weatherInterval, weatherInterval, null);
};

WeatherEffects.prototype.getCCPosition = function()
{
	var cmpRange = Engine.QueryInterface(SYSTEM_ENTITY, IID_RangeManager);
	if (!cmpRange) return undefined;
	var entities = cmpRange.GetEntitiesByPlayer(1);
	for (var i = 0; i < entities.length; i++)
	{
		var cmpId = Engine.QueryInterface(entities[i], IID_Identity);
		if (cmpId && cmpId.HasClass("CivCentre"))
		{
			var cmpPos = Engine.QueryInterface(entities[i], IID_Position);
			if (cmpPos && cmpPos.IsInWorld())
				return cmpPos.GetPosition();
		}
	}
	for (var i = 0; i < entities.length; i++)
	{
		var cmpPos = Engine.QueryInterface(entities[i], IID_Position);
		if (cmpPos && cmpPos.IsInWorld())
			return cmpPos.GetPosition();
	}
	return undefined;
};

WeatherEffects.prototype.createPlacedEntity = function(template)
{
	var entId = Engine.AddEntity(template);
	if (entId === INVALID_ENTITY) return INVALID_ENTITY;

	var cmpPos = Engine.QueryInterface(entId, IID_Position);
	if (cmpPos)
	{
		var pos = this.getCCPosition();
		if (pos)
			cmpPos.JumpTo(pos.x, pos.z);
	}
	return entId;
};

WeatherEffects.prototype.setSlot = function(slotName, template)
{
	var current = this.activeSlots[slotName];

	if (current && current.template === template)
		return;

	if (current)
	{
		Engine.DestroyEntity(current.entity);
		for (var i = 0; i < this.weatherEntities.length; i++)
			if (this.weatherEntities[i] === current.entity)
			{
				this.weatherEntities.splice(i, 1);
				break;
			}
	}

	if (!template)
	{
		delete this.activeSlots[slotName];
		return;
	}

	var entId = this.createPlacedEntity(template);
	if (entId === INVALID_ENTITY) return;

	this.weatherEntities.push(entId);
	this.activeSlots[slotName] = { "template": template, "entity": entId };
};

WeatherEffects.prototype.getMonthIndex = function()
{
	if (this.debugMonth !== undefined) return this.debugMonth;
	var cmpCal = Engine.QueryInterface(SYSTEM_ENTITY, IID_CalendarState);
	if (!cmpCal)
	{
		var cmpDNC = Engine.QueryInterface(SYSTEM_ENTITY, IID_DayNightCycle);
		if (!cmpDNC) return 0;
		var cd = cmpDNC.GetCycleDuration();
		var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
		var totalDays = Math.floor(cmpTimer.GetTime() / 1000 / cd);
		return Math.floor(totalDays / 30) % 12;
	}
	return cmpCal.GetMonthIndex();
};

WeatherEffects.prototype.getSeason = function()
{
	if (this.debugMonth !== undefined)
	{
		var m = this.debugMonth;
		if (m >= 2 && m <= 4) return "spring";
		if (m >= 5 && m <= 7) return "summer";
		if (m >= 8 && m <= 10) return "autumn";
		return "winter";
	}
	var cmpCal = Engine.QueryInterface(SYSTEM_ENTITY, IID_CalendarState);
	if (!cmpCal) return "spring";
	return cmpCal.GetSeason();
};

WeatherEffects.prototype.GetSeasonInfo = function()
{
	var info = {
		"month": this.getMonthIndex(),
		"season": this.getSeason(),
		"biome": this.biome
	};
	var cmpDNC = Engine.QueryInterface(SYSTEM_ENTITY, IID_DayNightCycle);
	info.hour = cmpDNC ? cmpDNC.GetHour() : 12;
	return info;
};

WeatherEffects.prototype.getHour = function()
{
	var cmpDNC = Engine.QueryInterface(SYSTEM_ENTITY, IID_DayNightCycle);
	if (!cmpDNC) return 12;
	return cmpDNC.GetHour();
};

WeatherEffects.prototype.getIntensity = function(curveName)
{
	var month = this.getMonthIndex();
	var curve = INTENSITY_CURVES[curveName];
	if (!curve || curve.length < 12) return 0;
	return curve[month];
};

WeatherEffects.prototype.getBiomeFactor = function(curveName)
{
	var factors = BIOME_FACTORS[curveName];
	if (!factors) return 1.0;
	var f = factors[this.biome];
	if (f === undefined) return 1.0;
	return f;
};

WeatherEffects.prototype.getPrimaryIntensity = function(effectName)
{
	return this.getIntensity(effectName) * this.getBiomeFactor(effectName);
};

WeatherEffects.prototype.selectPrimaryVariant = function(effectName)
{
	var variants = PRIMARY_VARIANTS[effectName];
	if (!variants) return null;
	var intensity = this.getPrimaryIntensity(effectName);
	var best = null;
	for (var i = 0; i < variants.length; i++)
		if (intensity >= variants[i].threshold)
			best = variants[i];
	return best;
};

WeatherEffects.prototype.pickPrimaryEffect = function()
{
	var candidates = ["rain"];
	for (var i = 0; i < candidates.length; i++)
	{
		var name = candidates[i];
		var intensity = this.getPrimaryIntensity(name);
		if (intensity >= 0.12 && Math.random() < intensity)
			return { "name": name, "intensity": intensity };
	}
	return { "name": null, "intensity": 0 };
};

WeatherEffects.prototype.slotShouldBeActive = function(slotName)
{
	var hour = this.getHour();

	if (slotName === "cherry")
	{
		if (hour < 6 || hour >= 19) return null;
		if (Math.random() < this.getIntensity("cherry"))
			return "special/weather_cherryblossom_big";
		return null;
	}

	if (slotName === "fireflies")
	{
		if (hour >= 5 && hour < 20) return null;
		if (Math.random() < this.getIntensity("fireflies"))
			return "special/weather_fireflies";
		return null;
	}

	return null;
};

WeatherEffects.prototype.updateWeather = function(data, lateness)
{
	var primary = this.pickPrimaryEffect();

	if (primary.intensity > 0 && primary.name)
	{
		var variant = this.selectPrimaryVariant(primary.name);
		this.setSlot("primary", variant ? variant.template : null);
	}
	else
		this.setSlot("primary", null);

	this.setSlot("cherry", this.slotShouldBeActive("cherry"));
	this.setSlot("fireflies", this.slotShouldBeActive("fireflies"));

	var primarySlot = this.activeSlots["primary"];
	var primaryTemplate = primarySlot ? primarySlot.template : "";
	this.currentWeather = SOUND_MAP[primaryTemplate];
	if (this.currentWeather === undefined) this.currentWeather = -1;
};

WeatherEffects.prototype.GetCurrentWeatherIndex = function()
{
	return this.currentWeather;
};

WeatherEffects.prototype.SetDebugMonth = function(month)
{
	this.debugMonth = month % 12;
	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	if (cmpTimer)
		cmpTimer.SetTimeout(SYSTEM_ENTITY, IID_WeatherEffects, "updateWeather", 0, null);
};

WeatherEffects.prototype.Serialize = function()
{
	return { "biome": this.biome, "currentWeather": this.currentWeather };
};

WeatherEffects.prototype.Deserialize = function(data)
{
	this.weatherEntities = [];
	this.activeSlots = {};
	this.currentWeather = -1;
	this.biome = data.biome || "temperate";
};

Engine.RegisterSystemComponentType(IID_WeatherEffects, "WeatherEffects", WeatherEffects);

// --- GuiInterface extensions ---

(function() {
	var orig = GuiInterface.prototype.exposedFunctions;
	GuiInterface.prototype.exposedFunctions = Object.assign({}, orig, {
		"GetCurrentWeatherIndex": 1,
		"GetSeasonInfo": 1,
		"SetSeasonBiome": 1,
		"SetDebugMonth": 1
	});
})();

GuiInterface.prototype.GetCurrentWeatherIndex = function(player, data)
{
	var cmpWE = Engine.QueryInterface(SYSTEM_ENTITY, IID_WeatherEffects);
	if (!cmpWE) return -1;
	return cmpWE.GetCurrentWeatherIndex();
};

GuiInterface.prototype.GetSeasonInfo = function(player, data)
{
	var cmpWE = Engine.QueryInterface(SYSTEM_ENTITY, IID_WeatherEffects);
	if (!cmpWE) return { "month": 0, "season": "spring", "biome": "temperate" };
	return cmpWE.GetSeasonInfo();
};

GuiInterface.prototype.SetSeasonBiome = function(player, data)
{
	if (!data || !data.biome) return;
	var cmpWE = Engine.QueryInterface(SYSTEM_ENTITY, IID_WeatherEffects);
	if (!cmpWE) return;
	cmpWE.biome = data.biome;
};

GuiInterface.prototype.SetDebugMonth = function(player, data)
{
	if (!data || data.month === undefined) return;
	var cmpWE = Engine.QueryInterface(SYSTEM_ENTITY, IID_WeatherEffects);
	if (!cmpWE) return;
	cmpWE.SetDebugMonth(data.month);
};
