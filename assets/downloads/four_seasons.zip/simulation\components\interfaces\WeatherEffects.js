Engine.RegisterInterface("WeatherEffects");
