Engine.ConfigDB_CreateValue("user", "gui.session.fourseasons", "true");
Engine.ReloadHotkeys();

var SEASONAL_SHIFTS = {
	"spring": { "r": 0,  "g": 10,  "b": 0   },
	"summer": { "r": 15, "g": 8,   "b": -8  },
	"autumn": { "r": 20, "g": -5,  "b": -12 },
	"winter": { "r": -8, "g": -8,  "b": 15  }
};

var BASE_KEYFRAMES = [
	{ hour: 0,  color: [5, 5, 30, 160],    curve: "linear" },
	{ hour: 5,  color: [5, 5, 30, 160],    curve: "easein" },
	{ hour: 7,  color: [40, 20, 8, 80],    curve: "linear" },
	{ hour: 8,  color: [40, 20, 8, 80],    curve: "linear" },
	{ hour: 10, color: [255, 255, 220, 8],  curve: "linear" },
	{ hour: 17, color: [255, 255, 220, 8],  curve: "easein" },
	{ hour: 19, color: [50, 15, 3, 80],    curve: "linear" },
	{ hour: 20, color: [50, 15, 3, 80],    curve: "linear" },
	{ hour: 22, color: [5, 5, 30, 160],    curve: "linear" },
	{ hour: 24, color: [5, 5, 30, 160],    curve: "linear" }
];

function clamp(val, min, max)
{
	return Math.min(Math.max(val, min), max);
}

function lerp(a, b, t)
{
	return a + (b - a) * t;
}

function lerpColor(c1, c2, t)
{
	return [
		Math.round(lerp(c1[0], c2[0], t)),
		Math.round(lerp(c1[1], c2[1], t)),
		Math.round(lerp(c1[2], c2[2], t)),
		Math.round(lerp(c1[3], c2[3], t))
	];
}

function getColorAtHour(hour, keyframes)
{
	for (var i = 0; i < keyframes.length - 1; i++)
	{
		var k0 = keyframes[i];
		var k1 = keyframes[i + 1];

		if (hour >= k0.hour && hour < k1.hour)
		{
			var t = (hour - k0.hour) / (k1.hour - k0.hour);
			if (k0.curve === "easein")
				t = t * t;
			return lerpColor(k0.color, k1.color, t);
		}
	}
	return keyframes[0].color;
}

function updateSeasonTint()
{
	var tintObj = Engine.TryGetGUIObjectByName("seasonTint");
	var tintParent = Engine.TryGetGUIObjectByName("seasonOverlay");
	if (!tintObj || !tintParent) return;

	if (!g_SimState)
	{
		tintParent.hidden = true;
		tintObj.hidden = true;
		return;
	}

	var info = Engine.GuiInterfaceCall("GetSeasonInfo");
	if (!info || info.hour === undefined)
	{
		tintParent.hidden = true;
		tintObj.hidden = true;
		return;
	}

	var hour = info.hour;
	var season = info.season || "spring";

	// Base day/night color from hour
	var baseColor = getColorAtHour(hour, BASE_KEYFRAMES);

	// Dusk orange boost: intensify seasonal shift during sunset (hour 17-20)
	var duskBoost = 1.0;
	if (hour >= 17 && hour < 20)
	{
		var duskT = (hour - 17) / 3;
		duskBoost = 1.0 + 0.4 * Math.sin(duskT * Math.PI);
	}

	// Seasonal shift with dusk boost
	var shift = SEASONAL_SHIFTS[season] || { r: 0, g: 0, b: 0 };

	// Final color: base + boosted seasonal shift, clamped to 0-255
	var finalColor = [
		clamp(baseColor[0] + Math.round(shift.r * duskBoost), 0, 255),
		clamp(baseColor[1] + Math.round(shift.g * duskBoost), 0, 255),
		clamp(baseColor[2] + Math.round(shift.b * duskBoost), 0, 255),
		baseColor[3]
	];

	tintParent.hidden = false;
	tintObj.hidden = false;
	tintObj.sprite = "color:" + finalColor[0] + " " + finalColor[1] + " " + finalColor[2] + " " + finalColor[3];
}

function initSeasonOverlay()
{
	if (!g_SimState)
	{
		setTimeout(initSeasonOverlay, 100);
		return;
	}
	updateSeasonTint();
	setTimeout(function repeat() { updateSeasonTint(); setTimeout(repeat, 500); }, 500);
}

updateSeasonTint();
setTimeout(initSeasonOverlay, 100);
