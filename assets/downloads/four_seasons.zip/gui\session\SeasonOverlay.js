Engine.ConfigDB_CreateValue("user", "gui.session.fourseasons", "true");
Engine.ReloadHotkeys();

var g_LastOverlaySeason = "";

var SEASONAL_SHIFTS = {
	"spring": { "r": 0,  "g": 10,  "b": 0   },
	"summer": { "r": 15, "g": 8,   "b": -8  },
	"autumn": { "r": 20, "g": -5,  "b": -12 },
	"winter": { "r": -8, "g": -8,  "b": 15  }
};

var BASE_KEYFRAMES = [
	{ hour: 0,  color: [5, 5, 30, 160],    curve: "linear" },
	{ hour: 5,  color: [5, 5, 30, 160],    curve: "easein" },
	{ hour: 7,  color: [40, 20, 8, 80],    curve: "linear" },
	{ hour: 8,  color: [40, 20, 8, 80],    curve: "linear" },
	{ hour: 10, color: [255, 255, 220, 8],  curve: "linear" },
	{ hour: 17, color: [255, 255, 220, 8],  curve: "easein" },
	{ hour: 19, color: [50, 15, 3, 80],    curve: "linear" },
	{ hour: 20, color: [50, 15, 3, 80],    curve: "linear" },
	{ hour: 22, color: [5, 5, 30, 160],    curve: "linear" },
	{ hour: 24, color: [5, 5, 30, 160],    curve: "linear" }
];

function clamp(val, min, max)
{
	return Math.min(Math.max(val, min), max);
}

function lerp(a, b, t)
{
	return a + (b - a) * t;
}

function lerpColor(c1, c2, t)
{
	return [
		Math.round(lerp(c1[0], c2[0], t)),
		Math.round(lerp(c1[1], c2[1], t)),
		Math.round(lerp(c1[2], c2[2], t)),
		Math.round(lerp(c1[3], c2[3], t))
	];
}

function getColorAtHour(hour, keyframes)
{
	for (var i = 0; i < keyframes.length - 1; i++)
	{
		var k0 = keyframes[i];
		var k1 = keyframes[i + 1];

		if (hour >= k0.hour && hour < k1.hour)
		{
			var t = (hour - k0.hour) / (k1.hour - k0.hour);
			if (k0.curve === "easein")
				t = t * t;
			return lerpColor(k0.color, k1.color, t);
		}
	}
	return keyframes[0].color;
}

function updateSeasonTint()
{
	var tintObj = Engine.GetGUIObjectByName("seasonTint");
	var tintParent = Engine.GetGUIObjectByName("seasonOverlay");
	if (!tintObj || !tintParent) return;

	if (!g_SimState)
	{
		tintParent.hidden = true;
		tintObj.hidden = true;
		return;
	}

	var info = Engine.GuiInterfaceCall("GetSeasonInfo");
	if (!info || info.hour === undefined)
	{
		tintParent.hidden = true;
		tintObj.hidden = true;
		return;
	}

	var hour = info.hour;
	var season = info.season || "spring";

	if (season !== g_LastOverlaySeason)
	{
		g_LastOverlaySeason = season;
		warn("FourSeasons: overlay season changed to " + season + " month=" + info.month + " hour=" + hour.toFixed(2));
	}

	// Base day/night color from hour
	var baseColor = getColorAtHour(hour, BASE_KEYFRAMES);

	// Seasonal shift
	var shift = SEASONAL_SHIFTS[season] || { r: 0, g: 0, b: 0 };

	// Final color: base + seasonal shift, clamped to 0-255
	var finalColor = [
		clamp(baseColor[0] + shift.r, 0, 255),
		clamp(baseColor[1] + shift.g, 0, 255),
		clamp(baseColor[2] + shift.b, 0, 255),
		baseColor[3]
	];

	tintParent.hidden = false;
	tintObj.hidden = false;
	tintObj.sprite = "color:" + finalColor[0] + " " + finalColor[1] + " " + finalColor[2] + " " + finalColor[3];
}

// Poll every 200ms for smooth transitions
function initSeasonOverlay()
{
	if (!g_SimState)
	{
		setTimeout(initSeasonOverlay, 500);
		return;
	}
	updateSeasonTint();
	setTimeout(function repeat() { updateSeasonTint(); setTimeout(repeat, 200); }, 200);
}

setTimeout(initSeasonOverlay, 500);
