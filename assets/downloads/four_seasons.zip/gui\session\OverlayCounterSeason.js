if (Engine.ConfigDB_GetValue("user", "gui.session.seasondisplay") !== "true")
	Engine.ConfigDB_CreateValue("user", "gui.session.seasondisplay", "true");

if (!Engine.ConfigDB_GetValue("user", "hotkey.season.display.toggle"))
{
	Engine.ConfigDB_CreateAndSaveValue("user", "hotkey.season.display.toggle", "Alt+S");
	Engine.ReloadHotkeys();
}

var g_MonthNames = [
	markForTranslation("January"),
	markForTranslation("February"),
	markForTranslation("March"),
	markForTranslation("April"),
	markForTranslation("May"),
	markForTranslation("June"),
	markForTranslation("July"),
	markForTranslation("August"),
	markForTranslation("September"),
	markForTranslation("October"),
	markForTranslation("November"),
	markForTranslation("December")
];

var g_BiomeNames = {
	"temperate": markForTranslation("Temperate"),
	"arctic": markForTranslation("Arctic"),
	"sahara": markForTranslation("Sahara"),
	"aegean": markForTranslation("Aegean"),
	"alpine": markForTranslation("Alpine"),
	"india": markForTranslation("India"),
	"savanna": markForTranslation("Savanna"),
	"steppe": markForTranslation("Steppe")
};

OverlayCounterTypes.prototype.SeasonDisplay = class extends OverlayCounter
{
	get()
	{
		if (!g_SimState)
			return "";

		var info = Engine.GuiInterfaceCall("GetSeasonInfo");
		if (!info || info.month === undefined)
			return "";

		var season = info.season || "spring";
		var icon = "";
		if (season === "spring") icon = markForTranslation("Spring");
		else if (season === "summer") icon = markForTranslation("Summer");
		else if (season === "autumn") icon = markForTranslation("Autumn");
		else icon = markForTranslation("Winter");

		var monthName = g_MonthNames[info.month] || "";
		var biomeName = g_BiomeNames[info.biome] || info.biome || markForTranslation("Temperate");

		return translate(icon) + ", " + translate(monthName) + " (" + translate(biomeName) + ")";
	}
};

OverlayCounterTypes.prototype.SeasonDisplay.prototype.Config =
	"gui.session.seasondisplay";

OverlayCounterTypes.prototype.SeasonDisplay.prototype.Hotkey =
	"season.display.toggle";
