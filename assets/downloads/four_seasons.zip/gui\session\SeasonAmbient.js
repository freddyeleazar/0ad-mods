var g_SeasonAmbientSounds = [
	{ "ogg": "audio/ambient/weather/rain_11.ogg", "gain": 0.08 }
];

var SEASONAL_AMBIENT = {
	"spring": { "ogg": "audio/ambient/dayscape/day_temperate_gen_03.ogg", "gain": 0.8 },
	"summer": { "ogg": "audio/ambient/dayscape/day_temperate_gen_03.ogg", "gain": 0.8 },
	"autumn": { "ogg": "audio/ambient/weather/snowstorm_11.ogg", "gain": 0.12 },
	"winter": { "ogg": "audio/ambient/weather/snowstorm_11.ogg", "gain": 0.12 }
};

var g_LastWeatherIndex = -2;
var g_LastSeason = "";
var g_DebugMonth = 0;
var g_DebugKeyWasPressed = false;
var g_PollTick = 0;

function getCurrentSeason()
{
	var info = Engine.GuiInterfaceCall("GetSeasonInfo");
	return info ? info.season : "spring";
}

function setGain(val)
{
	Engine.SetAmbientGain(val);
}

function startFadeTransition(targetOgg, targetGain)
{
	if (targetOgg)
	{
		setGain(targetGain);
		Engine.PlayAmbientSound(targetOgg, true);
	}
	else
		playSeasonalAmbient();
}

function playSeasonalAmbient()
{
	var season = getCurrentSeason();
	g_LastSeason = season;
	var a = SEASONAL_AMBIENT[season];
	if (a)
		startFadeTransition(a.ogg, a.gain);
}

function initSeasonBiome()
{
	var attrs = Engine.GuiInterfaceCall("GetInitAttributes");
	if (attrs && attrs.settings && attrs.settings.Biome)
		Engine.GuiInterfaceCall("SetSeasonBiome", { "biome": attrs.settings.Biome });
}

function PollAll()
{
	if (!g_SimState)
	{
		setTimeout(PollAll, 500);
		return;
	}

	g_PollTick++;

	if (Engine.HotkeyIsPressed("season.debug.next"))
	{
		if (!g_DebugKeyWasPressed)
		{
			g_DebugKeyWasPressed = true;
			g_DebugMonth = (g_DebugMonth + 1) % 12;
			Engine.GuiInterfaceCall("SetDebugMonth", { "month": g_DebugMonth });
		}
	}
	else
		g_DebugKeyWasPressed = false;

	if (g_PollTick % 4 === 1)
	{
		var index = Engine.GuiInterfaceCall("GetCurrentWeatherIndex");
		if (index !== undefined)
		{
			if (index !== g_LastWeatherIndex)
			{
				g_LastWeatherIndex = index;

				if (index === -1)
					playSeasonalAmbient();
				else
				{
					var weather = g_SeasonAmbientSounds[index];
					if (weather && weather.ogg)
						startFadeTransition(weather.ogg, weather.gain);
					else
						playSeasonalAmbient();
				}
			}
			else if (index === -1)
			{
				var season = getCurrentSeason();
				if (season !== g_LastSeason)
					playSeasonalAmbient();
			}
		}
	}

	setTimeout(PollAll, 500);
}

initSeasonBiome();
setTimeout(PollAll, 500);
