if (Engine.ConfigDB_GetValue("user", "gui.session.calendar") !== "true")
	Engine.ConfigDB_CreateValue("user", "gui.session.calendar", "true");

if (!Engine.ConfigDB_GetValue("user", "hotkey.calendar.toggle"))
{
	Engine.ConfigDB_CreateAndSaveValue("user", "hotkey.calendar.toggle", "Alt+C");
	Engine.ReloadHotkeys();
}

var g_CalendarConstants = {
	"DAYS_PER_MONTH": 30,
	"MONTHS_PER_YEAR": 12,
	"START_YEAR": 500,
	"MONTH_NAMES": [
		markForTranslation("January"),
		markForTranslation("February"),
		markForTranslation("March"),
		markForTranslation("April"),
		markForTranslation("May"),
		markForTranslation("June"),
		markForTranslation("July"),
		markForTranslation("August"),
		markForTranslation("September"),
		markForTranslation("October"),
		markForTranslation("November"),
		markForTranslation("December")
	]
};

OverlayCounterTypes.prototype.CalendarDate = class extends OverlayCounter
{
	constructor(overlayCounterManager)
	{
		super(overlayCounterManager);
		this.cycleDuration = 0;
	}

	get()
	{
		if (!g_SimState)
			return "";

		var seconds = g_SimState.timeElapsed / 1000;
		if (isNaN(seconds))
			return "";

		if (!this.cycleDuration)
			this.cycleDuration = Engine.GuiInterfaceCall("GetCycleDuration") || 900;

		var c = g_CalendarConstants;
		var totalDays = Math.floor(seconds / this.cycleDuration);
		var dayOfMonth = (totalDays % c.DAYS_PER_MONTH) + 1;
		var monthIndex = Math.floor(totalDays / c.DAYS_PER_MONTH) % c.MONTHS_PER_YEAR;
		var totalYears = Math.floor(totalDays / (c.DAYS_PER_MONTH * c.MONTHS_PER_YEAR));

		var displayYear = c.START_YEAR - totalYears;
		var yearStr;
		if (displayYear > 0)
			yearStr = displayYear + " " + translate("BC");
		else
			yearStr = (1 - displayYear) + " " + translate("AD");

		return sprintf(
			translate("Day %(day)d, %(month)s, %(year)s"),
			{
				"day": dayOfMonth,
				"month": translate(c.MONTH_NAMES[monthIndex]),
				"year": yearStr
			}
		);
	}
};

OverlayCounterTypes.prototype.CalendarDate.prototype.Config =
	"gui.session.calendar";

OverlayCounterTypes.prototype.CalendarDate.prototype.Hotkey =
	"calendar.toggle";
