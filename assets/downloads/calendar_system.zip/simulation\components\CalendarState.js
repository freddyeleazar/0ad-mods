function CalendarState() {}

CalendarState.prototype.Schema = "<a:component type='system'/><empty/>";

CalendarState.prototype.Init = function()
{
	this.DAYS_PER_MONTH = 30;
	this.MONTHS_PER_YEAR = 12;
	this.START_YEAR = 500;
};

CalendarState.prototype.GetTotalDays = function()
{
	var cmpDayNight = Engine.QueryInterface(SYSTEM_ENTITY, IID_DayNightCycle);
	if (!cmpDayNight) return 0;
	var cycleDuration = cmpDayNight.GetCycleDuration();
	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	var seconds = cmpTimer.GetTime() / 1000;
	return Math.floor(seconds / cycleDuration);
};

CalendarState.prototype.GetMonthIndex = function()
{
	var totalDays = this.GetTotalDays();
	return Math.floor(totalDays / this.DAYS_PER_MONTH) % this.MONTHS_PER_YEAR;
};

CalendarState.prototype.GetDayOfMonth = function()
{
	var totalDays = this.GetTotalDays();
	return (totalDays % this.DAYS_PER_MONTH) + 1;
};

CalendarState.prototype.GetSeason = function()
{
	var month = this.GetMonthIndex();
	if (month >= 2 && month <= 4) return "spring";
	if (month >= 5 && month <= 7) return "summer";
	if (month >= 8 && month <= 10) return "autumn";
	return "winter";
};

CalendarState.prototype.GetYearString = function()
{
	var totalDays = this.GetTotalDays();
	var totalYears = Math.floor(totalDays / (this.DAYS_PER_MONTH * this.MONTHS_PER_YEAR));
	var displayYear = this.START_YEAR - totalYears;
	if (displayYear > 0)
		return displayYear + " BC";
	return (1 - displayYear) + " AD";
};

CalendarState.prototype.Serialize = function() {};
CalendarState.prototype.Deserialize = function() {};

Engine.RegisterSystemComponentType(IID_CalendarState, "CalendarState", CalendarState);