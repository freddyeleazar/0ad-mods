(function() {
    var _origPerformBuilding = Builder.prototype.PerformBuilding;

    Builder.prototype.PerformBuilding = function(data, lateness)
    {
        _origPerformBuilding.call(this, data, lateness);

        if (this.target && this.GetRate() > 0)
        {
            SkillsRegistry.addXp(this.entity, "construction", this.GetRate() * 0.5);
        }
    };
})();
