/**
 * ResourceGatherer_Skills.js
 * Overrides ResourceGatherer to detect resource gathering activities
 * and award skill XP via SkillsRegistry.
 * Constructs full type string from lastCarriedType (generic.specific).
 */

var _origRG_CommitResources = ResourceGatherer.prototype.CommitResources;

ResourceGatherer.prototype.CommitResources = function(target)
{
    // Capture resource info BEFORE calling original
    var fullType = null;

    if (this.lastCarriedType && this.lastCarriedType.generic && this.lastCarriedType.specific)
    {
        // Construct full type: "food" + "." + "meat" = "food.meat"
        fullType = this.lastCarriedType.generic + "." + this.lastCarriedType.specific;
    }
    else if (this.lastCarriedType && this.lastCarriedType.generic)
    {
        // Fallback to generic type only
        fullType = this.lastCarriedType.generic;
    }
    else
    {
        // Last fallback: get first type from carrying
        for (var type in this.carrying)
        {
            if (this.carrying[type] > 0)
            {
                fullType = type;
                break;
            }
        }
    }

    // Capture total amount (single pass)
    var totalAmount = 0;
    if (!fullType)
    {
        for (var type in this.carrying)
        {
            var amount = this.carrying[type];
            if (amount > 0 && !fullType)
                fullType = type;
            totalAmount += amount;
        }
    }
    else
    {
        for (var type in this.carrying)
            totalAmount += this.carrying[type];
    }

    // Call original method (transfers resources)
    _origRG_CommitResources.call(this, target);

    // Award XP
    if (fullType && totalAmount > 0)
    {
        var match = SkillsRegistry.findSkillForResource(fullType);
        if (match)
            SkillsRegistry.addXp(this.entity, match.skill, totalAmount * match.xpPerUnit);
    }
};