/**
 * SkillsRegistry - Global skill tracking system for ExperienceSkills mod.
 * 100-level progression with dynamic bonus calculation.
 */
var SkillsRegistry = {
    MAX_LEVEL: 100,
    XP_BASE: 15,
    XP_GROWTH: 1.08,

    RANKS: [
        { minLevel: 10, title: "Apprentice", color: "green" },
        { minLevel: 25, title: "Expert", color: "blue" },
        { minLevel: 50, title: "Master", color: "purple" },
        { minLevel: 75, title: "Legendary", color: "orange" },
        { minLevel: 100, title: "Heroic", color: "gold" }
    ],

    BONUS_CONFIG: {
        "melee_combat":    { type: "multiply", path: "Attack/Melee/Damage/Hack",   perLevel: 0.04 },
        "ranged_combat":   { type: "multiply", path: "Attack/Ranged/Damage/Pierce", perLevel: 0.04 },
        "melee_resistance":  { type: "add", path: "Resistance/Entity/Damage/Hack",   perLevel: 0.35 },
        "ranged_resistance": { type: "add", path: "Resistance/Entity/Damage/Pierce", perLevel: 0.35 },
        "health":          { type: "add", path: "Health/Max",                        perLevel: 4 },
        "forager":         { type: "multiply", path: "ResourceGatherer/Rates/food.fruit",   perLevel: 0.02 },
        "hunter":          { type: "multiply", path: "ResourceGatherer/Rates/food.meat",    perLevel: 0.02 },
        "farmer":          { type: "multiply", path: "ResourceGatherer/Rates/food.grain",   perLevel: 0.02 },
        "fisher":          { type: "multiply", path: "ResourceGatherer/Rates/food.fish",    perLevel: 0.02 },
        "woodcutting":     { type: "multiply", path: "ResourceGatherer/Rates/wood.tree",    perLevel: 0.02 },
        "stonemason":      { type: "multiply", path: "ResourceGatherer/Rates/stone.rock",   perLevel: 0.02 },
        "mining":          { type: "multiply", path: "ResourceGatherer/Rates/metal.ore",    perLevel: 0.02 },
        "construction":    { type: "multiply", path: "Builder/Rate",                        perLevel: 0.04 }
    },

    EFFECT_DESCRIPTIONS: {
        "melee_combat":    function(lvl) { return "+" + (lvl * 4) + "% melee hack damage."; },
        "ranged_combat":   function(lvl) { return "+" + (lvl * 4) + "% ranged pierce damage."; },
        "melee_resistance":  function(lvl) { return "+" + (lvl * 0.35).toFixed(1) + " hack resistance."; },
        "ranged_resistance": function(lvl) { return "+" + (lvl * 0.35).toFixed(1) + " pierce resistance."; },
        "health":          function(lvl) { return "+" + (lvl * 4) + " maximum hitpoints."; },
        "forager":         function(lvl) { return "+" + (lvl * 2) + "% berry gathering rate."; },
        "hunter":          function(lvl) { return "+" + (lvl * 2) + "% hunting rate."; },
        "farmer":          function(lvl) { return "+" + (lvl * 2) + "% farming rate."; },
        "fisher":          function(lvl) { return "+" + (lvl * 2) + "% fishing rate."; },
        "woodcutting":     function(lvl) { return "+" + (lvl * 2) + "% wood gathering rate."; },
        "stonemason":      function(lvl) { return "+" + (lvl * 2) + "% stone gathering rate."; },
        "mining":          function(lvl) { return "+" + (lvl * 2) + "% metal mining rate."; },
        "construction":    function(lvl) { return "+" + (lvl * 4) + "% construction speed."; }
    },

    entities: {},
    skillDefs: null,

    loadDefs: function()
    {
        if (this.skillDefs)
            return;
        this.skillDefs = Engine.ReadJSONFile("simulation/data/skills.json").skills;
    },

    initEntity: function(entity)
    {
        this.loadDefs();
        if (!this.entities[entity])
        {
            this.entities[entity] = {};
            for (var skillName in this.skillDefs)
            {
                this.entities[entity][skillName] = { "xp": 0, "level": 0 };
            }
        }
    },

    xpForLevel: function(level)
    {
        return Math.floor(this.XP_BASE * Math.pow(this.XP_GROWTH, level));
    },

    totalXpForLevel: function(targetLevel)
    {
        var total = 0;
        for (var i = 0; i < targetLevel; i++)
            total += this.xpForLevel(i);
        return total;
    },

    getRank: function(level)
    {
        var rank = null;
        for (var i = this.RANKS.length - 1; i >= 0; i--)
        {
            if (level >= this.RANKS[i].minLevel)
            {
                rank = this.RANKS[i];
                break;
            }
        }
        return rank;
    },

    getEffectDescription: function(skillName, level)
    {
        if (level <= 0)
            return null;
        var fn = this.EFFECT_DESCRIPTIONS[skillName];
        return fn ? fn(level) : null;
    },

    getXp: function(entity, skillName)
    {
        this.initEntity(entity);
        return this.entities[entity][skillName] ? this.entities[entity][skillName].xp : 0;
    },

    getLevel: function(entity, skillName)
    {
        this.initEntity(entity);
        return this.entities[entity][skillName] ? this.entities[entity][skillName].level : 0;
    },

    addXp: function(entity, skillName, amount)
    {
        this.initEntity(entity);
        var skill = this.entities[entity][skillName];
        var def = this.skillDefs[skillName];

        if (!skill || !def || skill.level >= this.MAX_LEVEL)
            return false;

        skill.xp = Math.round((skill.xp + amount) * 10) / 10;

        var leveledUp = false;
        while (skill.level < this.MAX_LEVEL &&
               skill.xp >= this.totalXpForLevel(skill.level + 1))
        {
            skill.level++;
            leveledUp = true;
        }

        if (leveledUp)
            this.applyBonus(entity, skillName);

        return leveledUp;
    },

    applyBonus: function(entity, skillName)
    {
        var skill = this.entities[entity][skillName];
        if (!skill || skill.level <= 0)
            return;

        var cmpModifiersManager = Engine.QueryInterface(SYSTEM_ENTITY, IID_ModifiersManager);
        if (!cmpModifiersManager)
            return;

        var modName = "skill_" + skillName;
        cmpModifiersManager.RemoveAllModifiers(modName, entity);

        var config = this.BONUS_CONFIG[skillName];
        if (!config)
            return;

        var modifications = {};
        modifications[config.path] = {};

        if (config.type === "multiply")
            modifications[config.path].multiply = 1 + (skill.level * config.perLevel);
        else if (config.type === "add")
            modifications[config.path].add = skill.level * config.perLevel;

        cmpModifiersManager.AddModifiers(modName, modifications, entity);
    },

    getSkillsData: function(entity)
    {
        this.initEntity(entity);
        this.loadDefs();
        var result = {};
        var entitySkills = this.entities[entity];

        for (var skillName in entitySkills)
        {
            var skill = entitySkills[skillName];
            var def = this.skillDefs[skillName];
            var xpForNext = skill.level < this.MAX_LEVEL ? this.totalXpForLevel(skill.level + 1) : null;
            var rank = this.getRank(skill.level);

            result[skillName] = {
                "xp": skill.xp,
                "level": skill.level,
                "maxLevel": this.MAX_LEVEL,
                "name": def ? def.name : skillName,
                "type": def ? def.type : "unknown",
                "xpForNext": xpForNext,
                "rank": rank,
                "effectDescription": this.getEffectDescription(skillName, skill.level)
            };
        }
        return result;
    },

    findSkillForResource: function(resourceType)
    {
        this.loadDefs();
        for (var skillName in this.skillDefs)
        {
            var def = this.skillDefs[skillName];
            if (def.xpSources && def.xpSources.resource)
            {
                var types = def.xpSources.resource.types;
                for (var i = 0; i < types.length; i++)
                {
                    if (types[i] === resourceType || types[i].indexOf(resourceType + ".") === 0)
                    {
                        return { "skill": skillName, "xpPerUnit": def.xpSources.resource.xpPerUnit };
                    }
                }
            }
        }
        return null;
    },

    findSkillForAttack: function(attackType)
    {
        this.loadDefs();
        for (var skillName in this.skillDefs)
        {
            var def = this.skillDefs[skillName];
            if (def.xpSources && def.xpSources.attack)
            {
                var types = def.xpSources.attack.types;
                for (var i = 0; i < types.length; i++)
                {
                    if (types[i] === attackType)
                        return { "skill": skillName, "xpPerHit": def.xpSources.attack.xpPerHit };
                }
            }
        }
        return null;
    },

    findSkillForDefense: function(attackType)
    {
        this.loadDefs();
        for (var skillName in this.skillDefs)
        {
            var def = this.skillDefs[skillName];
            if (def.xpSources && def.xpSources.defense)
            {
                var types = def.xpSources.defense.types;
                for (var i = 0; i < types.length; i++)
                {
                    if (types[i] === attackType)
                        return { "skill": skillName, "xpPerHit": def.xpSources.defense.xpPerHit };
                }
            }
        }
        return null;
    },

    serialize: function()
    {
        var data = {};
        for (var eid in this.entities)
        {
            data[eid] = {};
            for (var skillName in this.entities[eid])
            {
                data[eid][skillName] = {
                    "xp": this.entities[eid][skillName].xp,
                    "level": this.entities[eid][skillName].level
                };
            }
        }
        return data;
    },

    deserialize: function(data)
    {
        this.loadDefs();
        this.entities = {};
        for (var eid in data)
        {
            this.entities[eid] = {};
            for (var skillName in data[eid])
            {
                this.entities[eid][skillName] = {
                    "xp": data[eid][skillName].xp,
                    "level": data[eid][skillName].level
                };
                this.applyBonus(+eid, skillName);
            }
        }
    }
};
