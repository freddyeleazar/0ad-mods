/**
 * GuiInterface_Skills.js
 * Overrides GuiInterface to include skills data in entity state.
 * This makes skills data available to the GUI selection panel.
 */

// Store reference to original method
var _origGuiInterface_GetEntityState = GuiInterface.prototype.GetEntityState;

/**
 * Override GetEntityState to include skills data.
 */
GuiInterface.prototype.GetEntityState = function(player, ent)
{
    // Call original method first
    var result = _origGuiInterface_GetEntityState.call(this, player, ent);

    if (result)
        result.skills = SkillsRegistry.getSkillsData(ent);

    return result;
};
