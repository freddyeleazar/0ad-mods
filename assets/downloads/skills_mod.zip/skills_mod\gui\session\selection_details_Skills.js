(function() {
    var _origDisplaySingle = displaySingle;

    function progressBar(xp, required, width)
    {
        var filled = Math.min(Math.round((xp / required) * width), width);
        var empty = width - filled;
        var bars = "";
        for (var i = 0; i < filled; i++) bars += "\u2588";
        for (var i = 0; i < empty; i++) bars += "\u2591";
        return bars;
    }

    displaySingle = function(entState)
    {
        _origDisplaySingle(entState);

        if (!entState.skills || Object.keys(entState.skills).length === 0)
            return;

        var skillsText = "";
        var skillCount = 0;

        for (var skillName in entState.skills)
        {
            var skill = entState.skills[skillName];

            if (skill.level === 0 && skill.xp === 0)
                continue;

            var color = "white";
            var titleText = "";

            if (skill.rank)
            {
                color = skill.rank.color;
                titleText = " \u2014 " + translate(skill.rank.title);
            }

            var line = "[color=\"" + color + "\"]" + translate(skill.name) + titleText + " Lv." + skill.level + "[/color]";

            if (skill.level < skill.maxLevel && skill.xpForNext)
            {
                var bar = progressBar(skill.xp, skill.xpForNext, 16);
                line += "\n" + bar + " " + Math.round(skill.xp) + "/" + Math.round(skill.xpForNext) + " XP";
            }
            else if (skill.level >= skill.maxLevel)
            {
                line += "\n" + progressBar(1, 1, 16) + " MAX";
            }

            if (skill.effectDescription)
                line += "\n" + translate(skill.effectDescription);

            skillsText += (skillCount > 0 ? "\n\n" : "") + line;
            skillCount++;
        }

        if (skillCount === 0)
            return;

        var iconBorder = Engine.GetGUIObjectByName("iconBorder");
        if (iconBorder)
        {
            var tooltipSep = iconBorder.tooltip ? "\n\n" : "";
            iconBorder.tooltip += tooltipSep +
                "[font=\"sans-bold-stroke-13\"]" + translate("Skills") + "[/font]\n" +
                "[font=\"sans-11\"]" + skillsText + "[/font]";
        }
    };
})();
