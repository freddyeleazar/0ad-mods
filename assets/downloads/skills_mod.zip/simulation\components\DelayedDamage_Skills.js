/**
 * DelayedDamage_Skills.js
 * Overrides DelayedDamage to detect successful attacks and award combat XP.
 * Awards offensive XP to attacker and defensive XP to target (if enemy).
 */

var _origDelayedDamage_Hit = DelayedDamage.prototype.Hit;

DelayedDamage.prototype.Hit = function(data, lateness)
{
    _origDelayedDamage_Hit.call(this, data, lateness);

    if (!data || !data.attacker || !data.target)
        return;

    // Award offensive XP to attacker
    if (data.type === "Melee")
    {
        var match = SkillsRegistry.findSkillForAttack("Melee");
        if (match)
            SkillsRegistry.addXp(data.attacker, match.skill, match.xpPerHit);
    }
    else if (data.type === "Ranged")
    {
        var match = SkillsRegistry.findSkillForAttack("Ranged");
        if (match)
            SkillsRegistry.addXp(data.attacker, match.skill, match.xpPerHit);
    }

    // Check if target is an enemy of the attacker
    var cmpTargetOwnership = Engine.QueryInterface(data.target, IID_Ownership);
    var cmpAttackerOwnership = Engine.QueryInterface(data.attacker, IID_Ownership);
    if (!cmpTargetOwnership || !cmpAttackerOwnership)
        return;

    if (cmpTargetOwnership.GetOwner() === cmpAttackerOwnership.GetOwner())
        return;

    // Target is an enemy - award defensive XP for receiving damage
    if (data.type === "Melee")
    {
        var match = SkillsRegistry.findSkillForDefense("Melee");
        if (match)
            SkillsRegistry.addXp(data.target, match.skill, match.xpPerHit);
    }
    else if (data.type === "Ranged")
    {
        var match = SkillsRegistry.findSkillForDefense("Ranged");
        if (match)
            SkillsRegistry.addXp(data.target, match.skill, match.xpPerHit);
    }
};
