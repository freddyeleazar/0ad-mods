/**
 * Health_Skills.js
 * Overrides Health to detect damage taken and award health XP.
 * Only awards XP when damage comes from an enemy.
 */

// Store reference to original method
var _origHealth_TakeDamage = Health.prototype.TakeDamage;

/**
 * Override TakeDamage to award XP when taking damage from enemies.
 */
Health.prototype.TakeDamage = function(amount, attacker, attackerOwner)
{
    // Call original method
    var result = _origHealth_TakeDamage.call(this, amount, attacker, attackerOwner);

    // Award health XP based on damage received from enemies
    if (result && result.healthChange && result.healthChange > 0 && attacker)
    {
        // Check if attacker is an enemy
        var cmpTargetOwnership = Engine.QueryInterface(this.entity, IID_Ownership);
        if (cmpTargetOwnership && cmpTargetOwnership.GetOwner() !== attackerOwner)
        {
            SkillsRegistry.addXp(this.entity, "health", result.healthChange * 0.5);
        }
    }

    return result;
};
