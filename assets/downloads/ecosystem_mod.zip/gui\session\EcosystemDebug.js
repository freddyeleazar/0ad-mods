function EcosystemDebug()
{
	this.ecosystemReady = false;
	this.checkCounter = 0;

	this.TryInit();
}

EcosystemDebug.prototype.TryInit = function()
{
	this.checkCounter++;

	if (this.checkCounter > 200)
		return;

	if (typeof Engine === "undefined" || typeof Engine.GuiInterfaceCall !== "function")
	{
		setTimeout(this.TryInit.bind(this), 500);
		return;
	}

	if (typeof registerSimulationUpdateHandler !== "function")
	{
		setTimeout(this.TryInit.bind(this), 500);
		return;
	}

	let result = Engine.GuiInterfaceCall("InitEcosystem", {});

	this.ecosystemReady = true;
	registerSimulationUpdateHandler(this.OnUpdate.bind(this));
};

EcosystemDebug.prototype.OnUpdate = function(simState)
{
};

var g_EcosystemDebug = new EcosystemDebug();
