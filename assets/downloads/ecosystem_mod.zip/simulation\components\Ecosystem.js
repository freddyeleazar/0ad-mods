function Ecosystem() {}

Ecosystem.prototype.Schema = "<a:component type='system'/><empty/>";

Ecosystem.prototype.Init = function()
{
	this.populations = {};
	this.progenitors = {};
	this.growthTimers = {};
	this.migrationCooldowns = {};

	this.REPRODUCTION_INTERVAL = 1440 * 1000;
	this.GROWTH_CHECK_INTERVAL = 1440 * 1000;
	this.MIGRATION_CHECK_INTERVAL = 4320 * 1000;
	this.MIGRATION_COOLDOWN = 4320 * 1000;

	this.POPULATION_LIMIT_MULTIPLIER = 1.1;
	this.MIGRATION_THRESHOLD = 0.5;

	this.CLUSTER_DISTANCE = 25;
	this.HABITAT_RADIUS = 30;
	this.BREEDING_DISTANCE = 40;
	this.FOLLOW_DISTANCE = 50;
	this.PROGENITOR_SEARCH_RADIUS = 80;

	this.SPECIES_LIST = [
		"fauna_deer",
		"fauna_boar",
		"fauna_sheep",
		"fauna_goat",
		"fauna_cattle_cow",
		"fauna_pig"
	];

	this.BABY_TEMPLATE_SUFFIX = "_baby";
	this.YOUNG_TEMPLATE_SUFFIX = "_young";

	this.babyToYoungTime = 1440 * 1000;
	this.youngToAdultTime = 2880 * 1000;

	this.initialized = false;

	warn("ECOSYSTEM: Init called - waiting for GUI to trigger initialization");
};

Ecosystem.prototype.IsFaunaSpecies = function(templateName)
{
	for (let species of this.SPECIES_LIST)
	{
		if (templateName.indexOf(species) !== -1)
			return true;
	}
	return false;
};

Ecosystem.prototype.GetSpeciesBase = function(templateName)
{
	for (let species of this.SPECIES_LIST)
	{
		if (templateName.indexOf(species) !== -1)
			return species;
	}
	return null;
};

Ecosystem.prototype.IsJuvenile = function(templateName)
{
	return templateName.indexOf(this.YOUNG_TEMPLATE_SUFFIX) !== -1;
};

Ecosystem.prototype.InitializeEcosystem = function()
{
	if (this.initialized)
	{
		return;
	}


	let cmpRangeManager = Engine.QueryInterface(SYSTEM_ENTITY, IID_RangeManager);
	if (!cmpRangeManager)
	{
		warn("ECOSYSTEM: RangeManager not found!");
		return;
	}

	let entities = cmpRangeManager.GetEntitiesByPlayer(0);
	warn("ECOSYSTEM: Found " + entities.length + " total entities owned by player 0");

	let speciesEntities = {};
	for (let ent of entities)
	{
		let cmpIdentity = Engine.QueryInterface(ent, IID_Identity);
		if (!cmpIdentity)
			continue;

		let template = Engine.QueryInterface(SYSTEM_ENTITY, IID_TemplateManager).GetCurrentTemplateName(ent);

		if (!this.IsFaunaSpecies(template))
			continue;

		let species = this.GetSpeciesBase(template);
		if (!species)
			continue;

		if (!speciesEntities[species])
			speciesEntities[species] = [];

		speciesEntities[species].push(ent);
	}


	for (let species in speciesEntities)
	{
		let animals = speciesEntities[species];
		let habitats = this.CalculateHabitats(animals);

		this.populations[species] = {
			initial: animals.length,
			current: animals.length,
			habitats: habitats
		};

		for (let habitat of habitats)
		{
			for (let ent of habitat.members)
			{
				this.growthTimers[ent] = {
					birthTime: 0,
					stage: "adult",
					progenitor: null
				};
			}
		}
	}

	this.initialized = true;

	let ccPos = this.GetPlayerCCPosition(1);
	if (ccPos)
};

Ecosystem.prototype.CalculateHabitats = function(entities)
{
	let habitats = [];
	let assigned = new Set();

	let cmpPosition = {};
	for (let ent of entities)
	{
		let pos = Engine.QueryInterface(ent, IID_Position);
		if (pos)
			cmpPosition[ent] = pos.GetPosition2D();
	}

	for (let ent of entities)
	{
		if (assigned.has(ent))
			continue;

		let cluster = [ent];
		assigned.add(ent);

		for (let other of entities)
		{
			if (assigned.has(other))
				continue;

			let dist = this.GetDistance(cmpPosition[ent], cmpPosition[other]);
			if (dist < this.CLUSTER_DISTANCE)
			{
				cluster.push(other);
				assigned.add(other);
			}
		}

		let center = this.CalculateCenter(cluster, cmpPosition);
		habitats.push({
			center: center,
			radius: this.HABITAT_RADIUS,
			members: cluster,
			initialCount: cluster.length
		});
	}

	return habitats;
};

Ecosystem.prototype.CalculateCenter = function(entities, positions)
{
	let sumX = 0;
	let sumY = 0;
	let count = 0;

	for (let ent of entities)
	{
		if (positions[ent])
		{
			sumX += positions[ent].x;
			sumY += positions[ent].y;
			count++;
		}
	}

	if (count === 0)
		return { x: 0, y: 0 };

	return { x: sumX / count, y: sumY / count };
};

Ecosystem.prototype.GetDistance = function(pos1, pos2)
{
	let dx = pos1.x - pos2.x;
	let dy = pos1.y - pos2.y;
	return Math.sqrt(dx * dx + dy * dy);
};

Ecosystem.prototype.StartTimers = function()
{
	let cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	if (!cmpTimer)
	{
		warn("ECOSYSTEM: Cannot start timers - Timer not available");
		return;
	}

	cmpTimer.SetInterval(SYSTEM_ENTITY, IID_Ecosystem, "CheckReproduction", this.REPRODUCTION_INTERVAL, this.REPRODUCTION_INTERVAL, null);

	cmpTimer.SetInterval(SYSTEM_ENTITY, IID_Ecosystem, "CheckGrowth", 1000, this.GROWTH_CHECK_INTERVAL, null);

	cmpTimer.SetInterval(SYSTEM_ENTITY, IID_Ecosystem, "CheckMigration", this.MIGRATION_CHECK_INTERVAL, this.MIGRATION_CHECK_INTERVAL, null);
};

Ecosystem.prototype.CheckReproduction = function(data, lateness)
{
	if (!this.initialized)
		return;

	let cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	let now = cmpTimer.GetTime();

	let cmpRangeManager = Engine.QueryInterface(SYSTEM_ENTITY, IID_RangeManager);
	if (!cmpRangeManager)
		return;

	for (let species in this.populations)
	{
		let pop = this.populations[species];

		if (pop.current >= pop.initial * this.POPULATION_LIMIT_MULTIPLIER)
			continue;

		let animals = this.GetAnimalsBySpecies(species);

		let pairs = this.FindBreedingPairs(animals, species);

		for (let pair of pairs)
		{
			if (pop.current >= pop.initial * this.POPULATION_LIMIT_MULTIPLIER)
				break;

			let baby = this.SpawnBaby(pair.mother, species);
			if (baby)
				pop.current++;
		}
	}
};

Ecosystem.prototype.GetAnimalsBySpecies = function(species)
{
	let cmpRangeManager = Engine.QueryInterface(SYSTEM_ENTITY, IID_RangeManager);
	let allEntities = cmpRangeManager.GetEntitiesByPlayer(0);
	let result = [];

	for (let ent of allEntities)
	{
		let cmpIdentity = Engine.QueryInterface(ent, IID_Identity);
		if (!cmpIdentity)
			continue;

		let template = Engine.QueryInterface(SYSTEM_ENTITY, IID_TemplateManager).GetCurrentTemplateName(ent);
		if (this.GetSpeciesBase(template) === species)
			result.push(ent);
	}

	return result;
};

Ecosystem.prototype.FindBreedingPairs = function(animals, species)
{
	let pairs = [];
	let available = new Set(animals);

	let positions = {};
	for (let ent of animals)
	{
		let cmpPosition = Engine.QueryInterface(ent, IID_Position);
		if (cmpPosition)
			positions[ent] = cmpPosition.GetPosition2D();
	}

	for (let mother of animals)
	{
		if (!available.has(mother))
			continue;

		let growth = this.growthTimers[mother];
		if (growth && growth.stage !== "adult")
			continue;

		for (let father of animals)
		{
			if (mother === father)
				continue;
			if (!available.has(father))
				continue;

			let growthF = this.growthTimers[father];
			if (growthF && growthF.stage !== "adult")
				continue;

			let dist = this.GetDistance(positions[mother], positions[father]);
			if (dist < this.BREEDING_DISTANCE)
			{
				pairs.push({ mother: mother, father: father });
				available.delete(mother);
				available.delete(father);
				break;
			}
		}
	}

	return pairs;
};

Ecosystem.prototype.GetPlayerCCPosition = function(playerId)
{
	let cmpRange = Engine.QueryInterface(SYSTEM_ENTITY, IID_RangeManager);
	if (!cmpRange) return null;

	let entities = cmpRange.GetEntitiesByPlayer(playerId);
	for (let ent of entities)
	{
		let cmpId = Engine.QueryInterface(ent, IID_Identity);
		if (cmpId && cmpId.HasClass("CivCentre"))
		{
			let cmpPos = Engine.QueryInterface(ent, IID_Position);
			if (cmpPos && cmpPos.IsInWorld())
				return cmpPos.GetPosition2D();
		}
	}
	return null;
};

Ecosystem.prototype.SpawnBaby = function(motherEnt, species)
{

	let cmpPosition = Engine.QueryInterface(motherEnt, IID_Position);
	if (!cmpPosition)
	{
		warn("ECOSYSTEM: Could not get position of mother entity!");
		return;
	}

	let pos = cmpPosition.GetPosition2D();
	let cmpTerrain = Engine.QueryInterface(SYSTEM_ENTITY, IID_Terrain);
	let motherGround = cmpTerrain ? cmpTerrain.GetGroundLevel(pos.x, pos.y) : -1;
	let ccPos = this.GetPlayerCCPosition(1);
	let ccGround = -1;
	if (ccPos && cmpTerrain)
		ccGround = cmpTerrain.GetGroundLevel(ccPos.x, ccPos.y);

	let babyTemplate = "gaia/" + species + this.BABY_TEMPLATE_SUFFIX;

	let babyEnt = Engine.AddEntity(babyTemplate);

	if (babyEnt === INVALID_ENTITY)
	{
		warn("ECOSYSTEM: Failed to create baby entity for " + species);
		return;
	}

	let cmpNewPosition = Engine.QueryInterface(babyEnt, IID_Position);
	if (cmpNewPosition)
	{
		let offsetX = (Math.random() - 0.5) * 4;
		let offsetY = (Math.random() - 0.5) * 4;
		cmpNewPosition.JumpTo(pos.x + offsetX, pos.y + offsetY);
		let cmpTerrain = Engine.QueryInterface(SYSTEM_ENTITY, IID_Terrain);
		if (cmpTerrain)
		{
			let ground = cmpTerrain.GetGroundLevel(pos.x + offsetX, pos.y + offsetY);
		}
		else
	}

	let cmpOwnership = Engine.QueryInterface(babyEnt, IID_Ownership);
	if (cmpOwnership)
		cmpOwnership.SetOwner(0);

	let cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	let now = cmpTimer.GetTime();

	this.growthTimers[babyEnt] = {
		birthTime: now,
		stage: "baby",
		progenitor: motherEnt
	};

	this.progenitors[babyEnt] = motherEnt;

	this.AddToHabitat(species, babyEnt, pos);

	return babyEnt;
};

Ecosystem.prototype.AddToHabitat = function(species, ent, pos)
{
	let pop = this.populations[species];
	if (!pop)
		return;

	let closestHabitat = null;
	let closestDist = Infinity;

	for (let habitat of pop.habitats)
	{
		let dist = this.GetDistance(pos, habitat.center);
		if (dist < closestDist)
		{
			closestDist = dist;
			closestHabitat = habitat;
		}
	}

	if (closestHabitat && closestDist < closestHabitat.radius * 2)
	{
		closestHabitat.members.push(ent);
	}
	else
	{
		pop.habitats.push({
			center: { x: pos.x, y: pos.y },
			radius: this.HABITAT_RADIUS,
			members: [ent],
			initialCount: 1
		});
	}
};

Ecosystem.prototype.CheckGrowth = function(data, lateness)
{
	if (!this.initialized)
		return;

	let cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	let now = cmpTimer.GetTime();

	for (let entKey in this.growthTimers)
	{
		let ent = +entKey;
		let growth = this.growthTimers[entKey];

		if (growth.migrating && growth.habitatCenter)
		{
			let cmpPos = Engine.QueryInterface(ent, IID_Position);
			if (cmpPos)
			{
				let pos = cmpPos.GetPosition2D();
				let dist = this.GetDistance(pos, growth.habitatCenter);
				if (dist < growth.habitatRadius)
				{
					let cmpUnitAI = Engine.QueryInterface(ent, IID_UnitAI);
					if (cmpUnitAI)
						cmpUnitAI.Stop();
					growth.migrating = false;
					delete growth.habitatCenter;
					delete growth.habitatRadius;
				}
			}
		}

		if (growth.stage === "adult")
			continue;

		let cmpIdentity = Engine.QueryInterface(ent, IID_Identity);
		if (!cmpIdentity)
			continue;

		let template = Engine.QueryInterface(SYSTEM_ENTITY, IID_TemplateManager).GetCurrentTemplateName(ent);
		let species = this.GetSpeciesBase(template);

		if (!species)
			continue;

		let elapsed = now - growth.birthTime;

		if (growth.stage === "baby" && elapsed >= this.babyToYoungTime)
		{
			this.GrowToYoung(ent, species, now);
		}
		else if (growth.stage === "young" && elapsed >= this.youngToAdultTime)
		{
			this.GrowToAdult(ent, species, now);
		}

		this.UpdateProgenitor(ent, species);
	}
};

Ecosystem.prototype.GrowToYoung = function(ent, species, now)
{
	let cmpPosition = Engine.QueryInterface(ent, IID_Position);
	if (!cmpPosition)
		return;

	let pos = cmpPosition.GetPosition2D();
	let progenitor = this.progenitors[ent];

	Engine.DestroyEntity(ent);

	let youngTemplate = "gaia/" + species + this.YOUNG_TEMPLATE_SUFFIX;
	let youngEnt = Engine.AddEntity(youngTemplate);

	if (youngEnt === INVALID_ENTITY)
		return;

	let cmpNewPosition = Engine.QueryInterface(youngEnt, IID_Position);
	if (cmpNewPosition)
		cmpNewPosition.JumpTo(pos.x, pos.y);

	let cmpOwnership = Engine.QueryInterface(youngEnt, IID_Ownership);
	if (cmpOwnership)
		cmpOwnership.SetOwner(0);

	this.growthTimers[youngEnt] = {
		birthTime: now,
		stage: "young",
		progenitor: progenitor
	};

	this.progenitors[youngEnt] = progenitor;

	delete this.growthTimers[ent];

	this.ReplaceInHabitat(species, ent, youngEnt);

	return youngEnt;
};

Ecosystem.prototype.GrowToAdult = function(ent, species, now)
{
	let cmpPosition = Engine.QueryInterface(ent, IID_Position);
	if (!cmpPosition)
		return;

	let pos = cmpPosition.GetPosition2D();

	Engine.DestroyEntity(ent);

	let adultTemplate = "gaia/" + species;
	let adultEnt = Engine.AddEntity(adultTemplate);

	if (adultEnt === INVALID_ENTITY)
		return;

	let cmpNewPosition = Engine.QueryInterface(adultEnt, IID_Position);
	if (cmpNewPosition)
		cmpNewPosition.JumpTo(pos.x, pos.y);

	let cmpOwnership = Engine.QueryInterface(adultEnt, IID_Ownership);
	if (cmpOwnership)
		cmpOwnership.SetOwner(0);

	this.growthTimers[adultEnt] = {
		birthTime: 0,
		stage: "adult",
		progenitor: null
	};

	delete this.growthTimers[ent];
	delete this.progenitors[ent];

	this.ReplaceInHabitat(species, ent, adultEnt);

	return adultEnt;
};

Ecosystem.prototype.ReplaceInHabitat = function(species, oldEnt, newEnt)
{
	let pop = this.populations[species];
	if (!pop)
		return;

	for (let habitat of pop.habitats)
	{
		for (let i = 0; i < habitat.members.length; i++)
		{
			if (habitat.members[i] === oldEnt)
			{
				habitat.members[i] = newEnt;
				return;
			}
		}
	}
};

Ecosystem.prototype.UpdateProgenitor = function(ent, species)
{
	let growth = this.growthTimers[ent];
	if (!growth || !growth.progenitor)
		return;

	let progenitor = growth.progenitor;

	let cmpIdentity = Engine.QueryInterface(progenitor, IID_Identity);
	if (!cmpIdentity)
	{
		let replacement = this.FindReplacementProgenitor(ent, species);
		if (replacement)
			growth.progenitor = replacement;
		else
			growth.progenitor = null;

		return;
	}

	let cmpPosition = Engine.QueryInterface(ent, IID_Position);
	let cmpProgenitorPos = Engine.QueryInterface(progenitor, IID_Position);

	if (!cmpPosition || !cmpProgenitorPos)
		return;

	let entPos = cmpPosition.GetPosition2D();
	let propPos = cmpProgenitorPos.GetPosition2D();

	let dist = this.GetDistance(entPos, propPos);

	if (dist > this.FOLLOW_DISTANCE)
	{
		let cmpUnitAI = Engine.QueryInterface(ent, IID_UnitAI);
		if (cmpUnitAI)
			cmpUnitAI.WalkToTarget(progenitor);
	}
};

Ecosystem.prototype.FindReplacementProgenitor = function(ent, species)
{
	let animals = this.GetAnimalsBySpecies(species);

	let cmpPosition = Engine.QueryInterface(ent, IID_Position);
	if (!cmpPosition)
		return null;

	let entPos = cmpPosition.GetPosition2D();

	let candidates = [];

	for (let other of animals)
	{
		if (other === ent)
			continue;

		let growth = this.growthTimers[other];
		if (!growth || growth.stage === "baby")
			continue;

		let cmpOtherPos = Engine.QueryInterface(other, IID_Position);
		if (!cmpOtherPos)
			continue;

		let dist = this.GetDistance(entPos, cmpOtherPos.GetPosition2D());

		if (dist < this.PROGENITOR_SEARCH_RADIUS)
			candidates.push({ ent: other, dist: dist });
	}

	if (candidates.length === 0)
		return null;

	candidates.sort((a, b) => a.dist - b.dist);

	return candidates[0].ent;
};

Ecosystem.prototype.CheckMigration = function(data, lateness)
{
	if (!this.initialized)
		return;

	let cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	let now = cmpTimer.GetTime();

	for (let species in this.populations)
	{
		let pop = this.populations[species];

		if (this.migrationCooldowns[species] && now < this.migrationCooldowns[species])
			continue;

		if (pop.current < pop.initial * this.MIGRATION_THRESHOLD)
		{
			this.TriggerMigration(species);
			this.migrationCooldowns[species] = now + this.MIGRATION_COOLDOWN;
		}
	}
};

Ecosystem.prototype.TriggerMigration = function(species)
{

	let pop = this.populations[species];
	if (!pop)
	{
		warn("ECOSYSTEM: No population data for " + species);
		return;
	}

	// Recalcular miembros de cada hábitat según posiciones actuales
	let allAnimals = this.GetAnimalsBySpecies(species);
	for (let habitat of pop.habitats)
	{
		habitat.members = allAnimals.filter(ent => {
			let cmpPos = Engine.QueryInterface(ent, IID_Position);
			if (!cmpPos || !cmpPos.IsInWorld()) return false;
			let pos = cmpPos.GetPosition2D();
			return this.GetDistance(pos, habitat.center) < habitat.radius;
		});
	}

	let targetHabitat = null;
	let maxVacancies = -1;

	for (let habitat of pop.habitats)
	{
		let vacancies = habitat.initialCount - habitat.members.length;
		if (vacancies > maxVacancies)
		{
			maxVacancies = vacancies;
			targetHabitat = habitat;
		}
	}

	if (!targetHabitat)
	{
		warn("ECOSYSTEM: No habitats found for migration!");
		if (pop.habitats.length > 0)
			targetHabitat = pop.habitats[0];
		else
			return;
	}


	for (let i = 0; i < 2; i++)
	{
		let spawnPoint = targetHabitat.center;
		let member = targetHabitat.members[0];
		if (member)
		{
			let cmpMemberPos = Engine.QueryInterface(member, IID_Position);
			if (cmpMemberPos && cmpMemberPos.IsInWorld())
				spawnPoint = cmpMemberPos.GetPosition2D();
		}


		let migrantEnt = Engine.AddEntity("gaia/" + species);

		if (migrantEnt === INVALID_ENTITY)
		{
			warn("ECOSYSTEM: Failed to create migrant entity for " + species);
			continue;
		}


		let cmpPosition = Engine.QueryInterface(migrantEnt, IID_Position);
		if (cmpPosition)
			cmpPosition.JumpTo(spawnPoint.x, spawnPoint.y);

		let cmpOwnership = Engine.QueryInterface(migrantEnt, IID_Ownership);
		if (cmpOwnership)
			cmpOwnership.SetOwner(0);

		// Walk toward habitat center
		let cmpUnitAI = Engine.QueryInterface(migrantEnt, IID_UnitAI);
		if (cmpUnitAI)
			cmpUnitAI.Walk(targetHabitat.center.x, targetHabitat.center.y);

		targetHabitat.members.push(migrantEnt);

		this.growthTimers[migrantEnt] = {
			birthTime: 0,
			stage: "adult",
			progenitor: null,
			migrating: true,
			habitatCenter: { x: targetHabitat.center.x, y: targetHabitat.center.y },
			habitatRadius: targetHabitat.radius
		};

		pop.current++;
	}

};

Ecosystem.prototype.OnGlobalOwnershipChanged = function(msg)
{
	if (!this.initialized)
		return;

	let ent = msg.entity;

	if (this.growthTimers[ent])
	{
		delete this.growthTimers[ent];
	}

	if (this.progenitors[ent])
	{
		delete this.progenitors[ent];
	}

	for (let species in this.populations)
	{
		let pop = this.populations[species];
		pop.current = this.GetAnimalsBySpecies(species).length;

		for (let habitat of pop.habitats)
		{
			habitat.members = habitat.members.filter(e => e !== ent);
		}
	}
};

Ecosystem.prototype.Serialize = function()
{
	return {
		populations: this.populations,
		progenitors: this.progenitors,
		growthTimers: this.growthTimers,
		migrationCooldowns: this.migrationCooldowns,
		initialized: this.initialized
	};
};

Ecosystem.prototype.Deserialize = function(data)
{
	this.populations = data.populations || {};
	this.progenitors = data.progenitors || {};
	this.growthTimers = data.growthTimers || {};
	this.migrationCooldowns = data.migrationCooldowns || {};
	this.initialized = data.initialized || false;

	if (this.initialized)
		this.StartTimers();
};

Engine.RegisterSystemComponentType(IID_Ecosystem, "Ecosystem", Ecosystem);
