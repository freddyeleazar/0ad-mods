var EcosystemExposedFunctions = {
	"InitEcosystem": 1,
	"GetEcosystemStatus": 1,
	"GetPopulations": 1,
	"GetHabitats": 1
};

if (typeof GuiInterface !== "undefined")
{
	let originalExposedFunctions = {};
	if (GuiInterface.prototype.exposedFunctions)
		originalExposedFunctions = { ...GuiInterface.prototype.exposedFunctions };

	GuiInterface.prototype.exposedFunctions = {
		...originalExposedFunctions,
		...EcosystemExposedFunctions
	};

	GuiInterface.prototype.InitEcosystem = function(player, data)
	{
		let cmpEcosystem = Engine.QueryInterface(SYSTEM_ENTITY, IID_Ecosystem);
		if (!cmpEcosystem)
			return { "success": false, "reason": "Ecosystem component not found" };

		if (cmpEcosystem.initialized)
			return { "success": true, "reason": "already initialized" };

		cmpEcosystem.InitializeEcosystem();
		cmpEcosystem.StartTimers();

		return { "success": true };
	};

	GuiInterface.prototype.GetEcosystemStatus = function(player, data)
	{
		let cmpEcosystem = Engine.QueryInterface(SYSTEM_ENTITY, IID_Ecosystem);
		if (!cmpEcosystem)
			return { "error": "Ecosystem not found" };

		return {
			initialized: cmpEcosystem.initialized,
			species: Object.keys(cmpEcosystem.populations)
		};
	};

	GuiInterface.prototype.GetPopulations = function(player, data)
	{
		let cmpEcosystem = Engine.QueryInterface(SYSTEM_ENTITY, IID_Ecosystem);
		if (!cmpEcosystem || !cmpEcosystem.populations)
			return {};

		let result = {};
		for (let species in cmpEcosystem.populations)
		{
			let pop = cmpEcosystem.populations[species];
			result[species] = {
				initial: pop.initial,
				current: pop.current,
				limit: Math.floor(pop.initial * 1.1)
			};
		}

		return result;
	};

	GuiInterface.prototype.GetHabitats = function(player, data)
	{
		let cmpEcosystem = Engine.QueryInterface(SYSTEM_ENTITY, IID_Ecosystem);
		if (!cmpEcosystem || !cmpEcosystem.populations)
			return {};

		let result = {};
		for (let species in cmpEcosystem.populations)
		{
			result[species] = cmpEcosystem.populations[species].habitats.map(h => ({
				center: h.center,
				radius: h.radius,
				memberCount: h.members.length
			}));
		}

		return result;
	};
}
