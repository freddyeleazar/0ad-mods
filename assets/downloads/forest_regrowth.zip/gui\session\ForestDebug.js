function ForestDebug()
{
	this.forestReady = false;
	this.checkCounter = 0;
	this.TryInit();
}

ForestDebug.prototype.TryInit = function()
{
	this.checkCounter++;

	if (this.checkCounter > 200)
		return;

	if (typeof Engine === "undefined" || typeof Engine.GuiInterfaceCall !== "function")
	{
		setTimeout(this.TryInit.bind(this), 500);
		return;
	}

	if (typeof registerSimulationUpdateHandler !== "function")
	{
		setTimeout(this.TryInit.bind(this), 500);
		return;
	}

	Engine.GuiInterfaceCall("InitForestRegrowth", {});

	this.forestReady = true;
	registerSimulationUpdateHandler(this.OnUpdate.bind(this));
};

ForestDebug.prototype.OnUpdate = function(simState)
{
};

var g_ForestDebug = new ForestDebug();
