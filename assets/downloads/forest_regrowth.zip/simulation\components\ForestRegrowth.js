function ForestRegrowth() {}

ForestRegrowth.prototype.Schema = "<a:component type='system'/><empty/>";

ForestRegrowth.prototype.Init = function()
{
	this.regrowingTrees = {};
	this.growthTimers = {};
	this.pendingGrowthEntities = {};
	this.nextRegrowId = 1;
	this.initialized = false;
};

ForestRegrowth.prototype.InitializeRegrowth = function()
{
	if (this.initialized)
		return;

	var cmpDayNight = Engine.QueryInterface(SYSTEM_ENTITY, IID_DayNightCycle);
	var dayMs = 900000;
	if (cmpDayNight)
		dayMs = cmpDayNight.GetCycleDuration() * 1000;

	this.dayMs = dayMs;
	this.REGROW_DELAY = 3 * dayMs;
	this.SAPLING_TO_YOUNG = 3 * dayMs;
	this.YOUNG_TO_ADULT = 6 * dayMs;
	this.CHECK_INTERVAL = 5000;

	this.initialized = true;
};

ForestRegrowth.prototype.StartTimers = function()
{
	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	if (!cmpTimer)
		return;

	cmpTimer.SetInterval(SYSTEM_ENTITY, IID_ForestRegrowth, "CheckRegrowth", this.CHECK_INTERVAL, this.CHECK_INTERVAL, null);
	cmpTimer.SetInterval(SYSTEM_ENTITY, IID_ForestRegrowth, "CheckGrowth", this.CHECK_INTERVAL, this.CHECK_INTERVAL, null);

	warn("FOREST: StartTimers interval=" + this.CHECK_INTERVAL + "ms");
};

ForestRegrowth.prototype.OnGlobalOwnershipChanged = function(msg)
{
	if (!this.initialized)
		return;

	if (msg.to !== undefined && msg.to >= 0)
		return;

	var ent = msg.entity;

	if (this.pendingGrowthEntities[ent])
	{
		delete this.pendingGrowthEntities[ent];
		return;
	}

	if (this.growthTimers[ent])
	{
		delete this.growthTimers[ent];
		return;
	}

	var cmpTmplMgr = Engine.QueryInterface(SYSTEM_ENTITY, IID_TemplateManager);
	if (!cmpTmplMgr)
		return;

	var templateName = cmpTmplMgr.GetCurrentTemplateName(ent);
	if (templateName.indexOf("gaia/tree/") === -1 && templateName.indexOf("gaia/fruit/") === -1)
		return;

	var cmpPos = Engine.QueryInterface(ent, IID_Position);
	if (!cmpPos || !cmpPos.IsInWorld())
		return;

	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	var now = cmpTimer ? cmpTimer.GetTime() : 0;

	var baseTemplate = templateName.replace(/_sapling$/, "").replace(/_young$/, "");

	var id = this.nextRegrowId++;
	var pos = cmpPos.GetPosition2D();
	this.regrowingTrees[id] = {
		position: pos,
		baseTemplate: baseTemplate,
		cutTime: now
	};

	warn("FOREST: OwnershipChanged ent=" + ent + " from=" + msg.from + " to=" + msg.to +
		" template=" + templateName + " base=" + baseTemplate +
		" pos=(" + pos.x.toFixed(0) + ", " + pos.y.toFixed(0) + ")");
};

ForestRegrowth.prototype.CheckRegrowth = function(data, lateness)
{
	if (!this.initialized)
		return;

	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	if (!cmpTimer)
		return;

	var now = cmpTimer.GetTime();

	for (var idKey in this.regrowingTrees)
	{
		var entry = this.regrowingTrees[idKey];
		if (now - entry.cutTime < this.REGROW_DELAY)
			continue;

		var saplingTemplate = entry.baseTemplate + "_sapling";
		var saplingEnt = Engine.AddEntity(saplingTemplate);

		if (saplingEnt === INVALID_ENTITY)
			continue;

		var cmpPos = Engine.QueryInterface(saplingEnt, IID_Position);
		if (cmpPos)
			cmpPos.JumpTo(entry.position.x, entry.position.y);

		var cmpOwnership = Engine.QueryInterface(saplingEnt, IID_Ownership);
		if (cmpOwnership)
			cmpOwnership.SetOwner(0);

		warn("FOREST: REGROWTH ent=" + saplingEnt + " template=" + saplingTemplate +
			" at (" + entry.position.x.toFixed(0) + ", " + entry.position.y.toFixed(0) + ")" +
			" cutTime=" + (entry.cutTime / 1000).toFixed(0) + "s ago=" + ((now - entry.cutTime) / 1000).toFixed(0) + "s");

		this.growthTimers[saplingEnt] = {
			birthTime: now,
			stage: "sapling",
			baseTemplate: entry.baseTemplate
		};

		delete this.regrowingTrees[idKey];
	}
};

ForestRegrowth.prototype.CheckGrowth = function(data, lateness)
{
	if (!this.initialized)
		return;

	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	if (!cmpTimer)
		return;

	var now = cmpTimer.GetTime();

	for (var entKey in this.growthTimers)
	{
		var ent = +entKey;
		var growth = this.growthTimers[entKey];

		if (growth.stage === "adult")
			continue;

		var elapsed = now - growth.birthTime;
		var nextStage = null;

		if (growth.stage === "sapling" && elapsed >= this.SAPLING_TO_YOUNG)
			nextStage = "young";
		else if (growth.stage === "young" && elapsed >= this.YOUNG_TO_ADULT)
			nextStage = "adult";

		if (!nextStage)
			continue;

		var cmpPos = Engine.QueryInterface(ent, IID_Position);
		if (!cmpPos)
			continue;

		var pos = cmpPos.GetPosition2D();
		var newTemplate = "";

		if (nextStage === "young")
			newTemplate = growth.baseTemplate + "_young";
		else
			newTemplate = growth.baseTemplate;

		var cmpSupply = Engine.QueryInterface(ent, IID_ResourceSupply);
		var currentAmount = cmpSupply ? cmpSupply.GetCurrentAmount() : -1;

		this.pendingGrowthEntities[ent] = true;
		Engine.DestroyEntity(ent);

		var newEnt = Engine.AddEntity(newTemplate);
		if (newEnt === INVALID_ENTITY)
			continue;

		var cmpNewPos = Engine.QueryInterface(newEnt, IID_Position);
		if (cmpNewPos)
			cmpNewPos.JumpTo(pos.x, pos.y);

		var cmpOwn = Engine.QueryInterface(newEnt, IID_Ownership);
		if (cmpOwn)
			cmpOwn.SetOwner(0);

		if (currentAmount >= 0)
		{
			var cmpNewSupply = Engine.QueryInterface(newEnt, IID_ResourceSupply);
			if (cmpNewSupply)
			{
				var maxAmount = cmpNewSupply.GetMaxAmount();
				cmpNewSupply.SetAmount(Math.min(currentAmount, maxAmount));
			}
		}

		warn("FOREST: GROWTH ent=" + ent + " " + growth.stage + "→" + nextStage +
			" newEnt=" + newEnt + " template=" + newTemplate +
			" birthTime=" + (growth.birthTime / 1000).toFixed(0) + "s elapsed=" + (elapsed / 1000).toFixed(0) + "s");

		delete this.growthTimers[entKey];

		if (nextStage !== "adult")
		{
			this.growthTimers[newEnt] = {
				birthTime: now,
				stage: nextStage,
				baseTemplate: growth.baseTemplate
			};
		}
	}
};

ForestRegrowth.prototype.Serialize = function()
{
	return {
		regrowingTrees: this.regrowingTrees,
		growthTimers: this.growthTimers,
		nextRegrowId: this.nextRegrowId,
		initialized: this.initialized,
		dayMs: this.dayMs
	};
};

ForestRegrowth.prototype.Deserialize = function(data)
{
	this.regrowingTrees = data.regrowingTrees || {};
	this.growthTimers = data.growthTimers || {};
	this.pendingGrowthEntities = {};
	this.nextRegrowId = data.nextRegrowId || 1;
	this.initialized = data.initialized || false;
	this.dayMs = data.dayMs || 900000;

	if (this.initialized)
	{
		this.REGROW_DELAY = 3 * this.dayMs;
		this.SAPLING_TO_YOUNG = 3 * this.dayMs;
		this.YOUNG_TO_ADULT = 6 * this.dayMs;
		this.CHECK_INTERVAL = 5000;
		this.StartTimers();

		warn("FOREST: Deserialize initialized=true" +
			" regrowing=" + Object.keys(this.regrowingTrees).length +
			" growing=" + Object.keys(this.growthTimers).length);
	}
};

Engine.RegisterSystemComponentType(IID_ForestRegrowth, "ForestRegrowth", ForestRegrowth);
