function ForestRegrowth() {}

ForestRegrowth.prototype.Schema = "<a:component type='system'/><empty/>";

ForestRegrowth.prototype.Init = function()
{
	this.regrowingTrees = {};
	this.growthTimers = {};
	this.pendingGrowthEntities = {};
	this.nextRegrowId = 1;
	this.initialized = false;
};

ForestRegrowth.prototype.InitializeRegrowth = function()
{
	if (this.initialized)
		return;

	var cmpDayNight = Engine.QueryInterface(SYSTEM_ENTITY, IID_DayNightCycle);
	var dayMs = 900000;
	if (cmpDayNight)
		dayMs = cmpDayNight.GetCycleDuration() * 1000;

	this.dayMs = dayMs;
	this.REGROW_DELAY = 3 * dayMs;
	this.SAPLING_TO_YOUNG = 3 * dayMs;
	this.YOUNG_TO_ADULT = 6 * dayMs;
	this.CHECK_INTERVAL = 5000;

	this.initialized = true;
};

ForestRegrowth.prototype.StartTimers = function()
{
	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	if (!cmpTimer)
		return;

	cmpTimer.SetInterval(SYSTEM_ENTITY, IID_ForestRegrowth, "CheckRegrowth", this.CHECK_INTERVAL, this.CHECK_INTERVAL, null);
	cmpTimer.SetInterval(SYSTEM_ENTITY, IID_ForestRegrowth, "CheckGrowth", this.CHECK_INTERVAL, this.CHECK_INTERVAL, null);
};

ForestRegrowth.prototype.GetSeasonGrowthMultiplier = function()
{
	var cmpWeather = Engine.QueryInterface(SYSTEM_ENTITY, IID_WeatherEffects);
	if (!cmpWeather)
		return 1.0;

	var info = cmpWeather.GetSeasonInfo();
	switch (info.season)
	{
	case "spring":
		return 1.5;
	case "summer":
		return 1.25;
	case "autumn":
		return 1.0;
	case "winter":
		return 0.5;
	default:
		return 1.0;
	}
};

ForestRegrowth.prototype.GetSeasonYieldMultiplier = function()
{
	var cmpWeather = Engine.QueryInterface(SYSTEM_ENTITY, IID_WeatherEffects);
	if (!cmpWeather)
		return 1.0;

	var info = cmpWeather.GetSeasonInfo();
	switch (info.season)
	{
	case "spring":
		return 2.0;
	case "summer":
		return 1.5;
	case "autumn":
		return 1.0;
	case "winter":
		return 0.5;
	default:
		return 1.0;
	}
};

ForestRegrowth.prototype.OnGlobalOwnershipChanged = function(msg)
{
	if (!this.initialized)
		return;

	if (msg.to !== undefined && msg.to >= 0)
		return;

	var ent = msg.entity;

	if (this.pendingGrowthEntities[ent])
	{
		delete this.pendingGrowthEntities[ent];
		return;
	}

	if (this.growthTimers[ent])
	{
		delete this.growthTimers[ent];
		return;
	}

	var cmpTmplMgr = Engine.QueryInterface(SYSTEM_ENTITY, IID_TemplateManager);
	if (!cmpTmplMgr)
		return;

	var templateName = cmpTmplMgr.GetCurrentTemplateName(ent);
	if (templateName.indexOf("gaia/tree/") === -1 && templateName.indexOf("gaia/fruit/") === -1)
		return;

	var cmpPos = Engine.QueryInterface(ent, IID_Position);
	if (!cmpPos || !cmpPos.IsInWorld())
		return;

	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	var now = cmpTimer ? cmpTimer.GetTime() : 0;

	var baseTemplate = templateName.replace(/_sapling$/, "").replace(/_young$/, "");

	var id = this.nextRegrowId++;
	var pos = cmpPos.GetPosition2D();
	this.regrowingTrees[id] = {
		position: pos,
		baseTemplate: baseTemplate,
		cutTime: now
	};
};

ForestRegrowth.prototype.CheckRegrowth = function(data, lateness)
{
	if (!this.initialized)
		return;

	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	if (!cmpTimer)
		return;

	var now = cmpTimer.GetTime();

	var regrowMult = this.GetSeasonGrowthMultiplier();
	var adjustedRegrowDelay = Math.round(this.REGROW_DELAY / regrowMult);

	for (var idKey in this.regrowingTrees)
	{
		var entry = this.regrowingTrees[idKey];
		if (now - entry.cutTime < adjustedRegrowDelay)
			continue;

		var saplingTemplate = entry.baseTemplate + "_sapling";
		var saplingEnt = Engine.AddEntity(saplingTemplate);

		if (saplingEnt === INVALID_ENTITY)
			continue;

		var cmpPos = Engine.QueryInterface(saplingEnt, IID_Position);
		if (cmpPos)
			cmpPos.JumpTo(entry.position.x, entry.position.y);

		var cmpOwnership = Engine.QueryInterface(saplingEnt, IID_Ownership);
		if (cmpOwnership)
			cmpOwnership.SetOwner(0);

		if (entry.baseTemplate.indexOf("gaia/fruit/") !== -1)
		{
			var cmpSupply = Engine.QueryInterface(saplingEnt, IID_ResourceSupply);
			if (cmpSupply)
			{
				var maxAmt = cmpSupply.GetMaxAmount();
				var yieldMult = this.GetSeasonYieldMultiplier();
				cmpSupply.SetAmount(Math.round(maxAmt * yieldMult));
			}
		}

		this.growthTimers[saplingEnt] = {
			birthTime: now,
			stage: "sapling",
			baseTemplate: entry.baseTemplate
		};

		delete this.regrowingTrees[idKey];
	}
};

ForestRegrowth.prototype.CheckGrowth = function(data, lateness)
{
	if (!this.initialized)
		return;

	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	if (!cmpTimer)
		return;

	var now = cmpTimer.GetTime();

	for (var entKey in this.growthTimers)
	{
		var ent = +entKey;
		var growth = this.growthTimers[entKey];

		if (growth.stage === "adult")
			continue;

		var elapsed = now - growth.birthTime;
		var growthMult = this.GetSeasonGrowthMultiplier();
		var adjSaplingTime = Math.round(this.SAPLING_TO_YOUNG / growthMult);
		var adjYoungTime = Math.round(this.YOUNG_TO_ADULT / growthMult);
		var nextStage = null;

		if (growth.stage === "sapling" && elapsed >= adjSaplingTime)
			nextStage = "young";
		else if (growth.stage === "young" && elapsed >= adjYoungTime)
			nextStage = "adult";

		if (!nextStage)
			continue;

		var cmpPos = Engine.QueryInterface(ent, IID_Position);
		if (!cmpPos)
			continue;

		var pos = cmpPos.GetPosition2D();
		var newTemplate = "";

		if (nextStage === "young")
			newTemplate = growth.baseTemplate + "_young";
		else
			newTemplate = growth.baseTemplate;

		var cmpSupply = Engine.QueryInterface(ent, IID_ResourceSupply);
		var currentAmount = cmpSupply ? cmpSupply.GetCurrentAmount() : -1;

		this.pendingGrowthEntities[ent] = true;
		Engine.DestroyEntity(ent);

		var newEnt = Engine.AddEntity(newTemplate);
		if (newEnt === INVALID_ENTITY)
			continue;

		var cmpNewPos = Engine.QueryInterface(newEnt, IID_Position);
		if (cmpNewPos)
			cmpNewPos.JumpTo(pos.x, pos.y);

		var cmpOwn = Engine.QueryInterface(newEnt, IID_Ownership);
		if (cmpOwn)
			cmpOwn.SetOwner(0);

		if (currentAmount >= 0)
		{
			var cmpNewSupply = Engine.QueryInterface(newEnt, IID_ResourceSupply);
			if (cmpNewSupply)
			{
				var maxAmount = cmpNewSupply.GetMaxAmount();
				cmpNewSupply.SetAmount(Math.min(currentAmount, maxAmount));
			}
		}

		delete this.growthTimers[entKey];

		if (nextStage !== "adult")
		{
			this.growthTimers[newEnt] = {
				birthTime: now,
				stage: nextStage,
				baseTemplate: growth.baseTemplate
			};
		}
	}
};

ForestRegrowth.prototype.Serialize = function()
{
	return {
		regrowingTrees: this.regrowingTrees,
		growthTimers: this.growthTimers,
		nextRegrowId: this.nextRegrowId,
		initialized: this.initialized,
		dayMs: this.dayMs
	};
};

ForestRegrowth.prototype.Deserialize = function(data)
{
	this.regrowingTrees = data.regrowingTrees || {};
	this.growthTimers = data.growthTimers || {};
	this.pendingGrowthEntities = {};
	this.nextRegrowId = data.nextRegrowId || 1;
	this.initialized = data.initialized || false;
	this.dayMs = data.dayMs || 900000;

	if (this.initialized)
	{
		this.REGROW_DELAY = 3 * this.dayMs;
		this.SAPLING_TO_YOUNG = 3 * this.dayMs;
		this.YOUNG_TO_ADULT = 6 * this.dayMs;
		this.CHECK_INTERVAL = 5000;
		this.StartTimers();
	}
};

Engine.RegisterSystemComponentType(IID_ForestRegrowth, "ForestRegrowth", ForestRegrowth);
