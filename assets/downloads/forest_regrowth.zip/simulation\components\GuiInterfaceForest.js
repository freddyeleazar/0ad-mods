var ForestExposedFunctions = {
	"InitForestRegrowth": 1
};

if (typeof GuiInterface !== "undefined")
{
	var originalExposedFunctions = {};
	if (GuiInterface.prototype.exposedFunctions)
		originalExposedFunctions = { ...GuiInterface.prototype.exposedFunctions };

	GuiInterface.prototype.exposedFunctions = {
		...originalExposedFunctions,
		...ForestExposedFunctions
	};

	GuiInterface.prototype.InitForestRegrowth = function(player, data)
	{
		var cmpForest = Engine.QueryInterface(SYSTEM_ENTITY, IID_ForestRegrowth);
		if (!cmpForest)
			return { "success": false, "reason": "ForestRegrowth component not found" };

		if (cmpForest.initialized)
			return { "success": true, "reason": "already initialized" };

		cmpForest.InitializeRegrowth();
		cmpForest.StartTimers();

		return { "success": true };
	};
}
