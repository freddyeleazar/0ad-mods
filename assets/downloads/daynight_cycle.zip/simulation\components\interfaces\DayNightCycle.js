Engine.RegisterInterface("DayNightCycle");
