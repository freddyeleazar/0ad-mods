function DayNightCycle() {}

DayNightCycle.prototype.Schema = "<a:component type='system'/><empty/>";

DayNightCycle.prototype.Init = function()
{
	this.CYCLE_DURATION = 900;
	this.START_HOUR = 8;
};

DayNightCycle.prototype.GetHour = function()
{
	var cmpTimer = Engine.QueryInterface(SYSTEM_ENTITY, IID_Timer);
	var seconds = cmpTimer.GetTime() / 1000;
	var phaseTime = ((seconds % this.CYCLE_DURATION) / this.CYCLE_DURATION
	                + this.START_HOUR / 24) % 1;
	return phaseTime * 24;
};

DayNightCycle.prototype.GetDayPhase = function()
{
	var hour = this.GetHour();
	if (hour >= 5 && hour < 7) return "dawn";
	if (hour >= 7 && hour < 18) return "day";
	if (hour >= 18 && hour < 20) return "dusk";
	return "night";
};

DayNightCycle.prototype.GetCycleDuration = function()
{
	return this.CYCLE_DURATION;
};

DayNightCycle.prototype.Serialize = function() {};
DayNightCycle.prototype.Deserialize = function() {};

Engine.RegisterSystemComponentType(IID_DayNightCycle, "DayNightCycle", DayNightCycle);
