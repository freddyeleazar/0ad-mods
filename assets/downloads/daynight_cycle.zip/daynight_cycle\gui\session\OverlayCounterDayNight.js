if (Engine.ConfigDB_GetValue("user", "gui.session.daynightcycle") !== "true")
	Engine.ConfigDB_CreateValue("user", "gui.session.daynightcycle", "true");

/**
 * Day/Night Cycle overlay counter with color tint overlay.
 * Shows phase + virtual time and applies a full-screen color tint.
 *
 * CYCLE_DURATION: 1440 simulation seconds = 24 in-game hours (at 1x speed)
 */
OverlayCounterTypes.prototype.DayNight = class extends OverlayCounter
{
	constructor(overlayCounterManager)
	{
		super(overlayCounterManager);

		this.CYCLE_DURATION = 1440;
		this.START_HOUR = 8;

		// Color keyframes: each entry defines color at that hour and curve to next
		// curve: "linear" or "easein" (quadratic t*t)
		this.COLOR_KEYS = [
			{ hour: 0,  color: [5, 5, 30, 160],    curve: "linear" },
			{ hour: 5,  color: [5, 5, 30, 160],    curve: "easein" },
			{ hour: 7,  color: [40, 20, 8, 80],    curve: "linear" },
			{ hour: 8,  color: [40, 20, 8, 80],    curve: "linear" },
			{ hour: 10, color: [255, 255, 220, 8],  curve: "linear" },
			{ hour: 17, color: [255, 255, 220, 8],  curve: "easein" },
			{ hour: 19, color: [50, 15, 3, 80],    curve: "linear" },
			{ hour: 20, color: [50, 15, 3, 80],    curve: "linear" },
			{ hour: 22, color: [5, 5, 30, 160],    curve: "linear" },
			{ hour: 24, color: [5, 5, 30, 160],    curve: "linear" }
		];

		this.tintFound = false;
		this.tintObj = undefined;
		this.tintParent = undefined;
	}

	getTint()
	{
		if (!this.tintFound)
		{
			this.tintObj = Engine.GetGUIObjectByName("dayNightTint");
			this.tintParent = Engine.GetGUIObjectByName("dayNightOverlay");
			if (this.tintObj && this.tintParent)
				this.tintFound = true;
		}
		return this.tintObj;
	}

	lerp(a, b, t)
	{
		return a + (b - a) * t;
	}

	lerpColor(c1, c2, t)
	{
		return [
			Math.round(this.lerp(c1[0], c2[0], t)),
			Math.round(this.lerp(c1[1], c2[1], t)),
			Math.round(this.lerp(c1[2], c2[2], t)),
			Math.round(this.lerp(c1[3], c2[3], t))
		];
	}

	getColorAtHour(hour)
	{
		for (var i = 0; i < this.COLOR_KEYS.length - 1; i++)
		{
			var k0 = this.COLOR_KEYS[i];
			var k1 = this.COLOR_KEYS[i + 1];

			if (hour >= k0.hour && hour < k1.hour)
			{
				var t = (hour - k0.hour) / (k1.hour - k0.hour);
				if (k0.curve === "easein")
					t = t * t;
				return this.lerpColor(k0.color, k1.color, t);
			}
		}

		return this.COLOR_KEYS[0].color;
	}

	get()
	{
		var tint = this.getTint();
		if (!g_SimState)
		{
			if (tint && this.tintParent)
			{
				tint.hidden = true;
				this.tintParent.hidden = true;
			}
			return "";
		}

		var seconds = g_SimState.timeElapsed / 1000;
		if (isNaN(seconds) || seconds === undefined)
		{
			if (tint && this.tintParent)
			{
				tint.hidden = true;
				this.tintParent.hidden = true;
			}
			return "";
		}

		var phaseTime = ((seconds % this.CYCLE_DURATION) / this.CYCLE_DURATION + this.START_HOUR / 24) % 1;

		// Calculate virtual hours and minutes
		var totalMinutes = phaseTime * 24 * 60;
		var hours = Math.floor(totalMinutes / 60);
		var minutes = Math.floor(totalMinutes % 60);

		var timeStr = (hours < 10 ? "0" : "") + hours + ":" +
		              (minutes < 10 ? "0" : "") + minutes;

		// Determine phase name
		var phase;
		if (phaseTime < 0.25)
			phase = "NOCHE";
		else if (phaseTime < 0.333)
			phase = "AMANECER";
		else if (phaseTime < 0.75)
			phase = "DIA";
		else if (phaseTime < 0.833)
			phase = "ATARDECER";
		else
			phase = "NOCHE";

		// Update color tint overlay using absolute hour keyframes
		if (tint && this.tintParent)
		{
			var virtualHour = phaseTime * 24;
			var c = this.getColorAtHour(virtualHour);
			this.tintParent.hidden = false;
			tint.hidden = false;
			tint.sprite = "color:" + c[0] + " " + c[1] + " " + c[2] + " " + c[3];
		}

		return phase + " " + timeStr;
	}
};

OverlayCounterTypes.prototype.DayNight.prototype.Config =
	"gui.session.daynightcycle";

OverlayCounterTypes.prototype.DayNight.prototype.Hotkey =
	"daynightcycle.toggle";
