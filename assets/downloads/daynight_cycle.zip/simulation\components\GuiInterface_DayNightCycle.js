Object.assign(GuiInterface.prototype.exposedFunctions, { "GetCycleDuration": 1 });

GuiInterface.prototype.GetCycleDuration = function(player) {
	var cmpDayNight = Engine.QueryInterface(SYSTEM_ENTITY, IID_DayNightCycle);
	if (!cmpDayNight) return 900;
	return cmpDayNight.GetCycleDuration();
};
