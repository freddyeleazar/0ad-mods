/**
 * Personal Names Mod - selection_details.js override.
 * Displays personal name instead of SpecificName for human units.
 */
(function() {
    var _origDisplaySingle = displaySingle;
    displaySingle = function(entState)
    {
        _origDisplaySingle(entState);

        if (entState.identity && entState.identity.name)
        {
            var primaryObject = Engine.GetGUIObjectByName("primary");
            if (primaryObject)
                primaryObject.caption = translate(entState.identity.name);

            var iconBorder = Engine.GetGUIObjectByName("iconBorder");
            if (iconBorder && iconBorder.tooltip)
            {
                var template = GetTemplateData(entState.template);
                var personalName = translate(entState.identity.name);
                var genericName = template.name.generic;

                var newNameLine = genericName
                    ? sprintf(translate("%(name)s (%(generic)s)"), {"name": personalName, "generic": genericName})
                    : personalName;

                var lines = iconBorder.tooltip.split("\n");
                lines[0] = setStringTags(newNameLine, g_TooltipTextFormats.namePrimaryBig);
                iconBorder.tooltip = lines.join("\n");
            }
        }
    };
})();
