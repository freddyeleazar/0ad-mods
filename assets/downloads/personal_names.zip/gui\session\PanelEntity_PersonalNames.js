/**
 * Personal Names Mod - PanelEntity.js override.
 * Displays personal name instead of SpecificName in entity panel.
 */

// Store reference to original PanelEntity constructor
var _originalPanelEntity = PanelEntity;

PanelEntity = function(selection, entityID, buttonID, orderKey)
{
    // Call original constructor
    _originalPanelEntity.call(this, selection, entityID, buttonID, orderKey);

    // If entity has a personal name, override the tooltip
    const entityState = GetEntityState(entityID);
    if (entityState.identity && entityState.identity.name)
    {
        this.nameTooltip = setStringTags(translate(entityState.identity.name), this.NameTags) + "\n";
    }
};

// Copy prototype from original
PanelEntity.prototype = _originalPanelEntity.prototype;
