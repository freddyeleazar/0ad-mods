/**
 * Personal Names Mod - Identity component override.
 * Assigns unique personal names to human units based on gender and civilization.
 * Heroes keep their fixed names (GenericName/SpecificName).
 */

// Store reference to original Init function
var _originalIdentityInit = Identity.prototype.Init;

/**
 * Override Init to assign personal names after original initialization.
 */
Identity.prototype.Init = function()
{
    // Execute original Init (sets phenotype, classes, controllable, etc.)
    _originalIdentityInit.call(this);

    // Only assign names to human units (not heroes, not animals, not buildings)
    // Check for Unit class (all human units have this)
    // Check for Organic class (living entities)
    // Exclude Heroes (they have fixed historical names)
    if (!this.HasClass("Unit") || !this.HasClass("Organic") || this.HasClass("Hero"))
        return;

    // Get civilization and gender
    const civ = this.template.Civ;
    const phenotype = this.phenotype; // "male" or "female"

    // Get unique name from global registry
    const name = getUniquePersonalName(civ, phenotype);
    if (name)
        this.name = name;
};

// Re-register component type to ensure engine recognizes schema and listener changes
Engine.ReRegisterComponentType(IID_Identity, "Identity", Identity);
