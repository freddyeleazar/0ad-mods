/**
 * Personal Names Mod - GuiInterface component override.
 * Exposes personal name to GUI via GetEntityState.
 */

// Store reference to original GetEntityState
var _originalGetEntityState = GuiInterface.prototype.GetEntityState;

/**
 * Override GetEntityState to include personal name in identity section.
 */
GuiInterface.prototype.GetEntityState = function(player, ent)
{
    // Call original function
    const ret = _originalGetEntityState.call(this, player, ent);

    // Add personal name to identity if available and not already populated
    if (ret && ret.identity && !ret.identity.name)
    {
        const cmpIdentity = Engine.QueryInterface(ent, IID_Identity);
        if (cmpIdentity)
            ret.identity.name = cmpIdentity.GetName();
    }

    return ret;
};
