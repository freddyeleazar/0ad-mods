/**
 * Personal Names Mod - Global name registry and management.
 * Loads names from JSON and ensures unique assignment per game session.
 */

var g_PersonalNames = {};
var g_UsedPersonalNames = {};
var g_PersonalNamesLoaded = false;

/**
 * Load personal names from JSON files.
 * Called lazily on first use to ensure files are available.
 */
function ensurePersonalNamesLoaded()
{
    if (g_PersonalNamesLoaded)
        return;

    g_PersonalNamesLoaded = true;

    try {
        const files = Engine.ListDirectoryFiles("simulation/data/", "personal_names*.json", false);
        for (const filename of files)
        {
            const data = Engine.ReadJSONFile(filename);
            for (const civ in data)
            {
                if (!g_PersonalNames[civ])
                    g_PersonalNames[civ] = {};
                if (!g_UsedPersonalNames[civ])
                    g_UsedPersonalNames[civ] = {};

                for (const gender in data[civ])
                {
                    g_PersonalNames[civ][gender] = data[civ][gender];
                    g_UsedPersonalNames[civ][gender] = [];
                }
            }
        }
    }
    catch (e)
    {
        warn("PersonalNames: Failed to load personal names: " + e);
    }
}

/**
 * Get a unique personal name for a unit.
 * Names are consumed once used, ensuring uniqueness within a game.
 *
 * @param {string} civ - Civilization code (e.g., "athen", "rome", "spart")
 * @param {string} gender - "male" or "female"
 * @return {string|null} A unique name, or null if no names available
 */
function getUniquePersonalName(civ, gender)
{
    ensurePersonalNamesLoaded();

    if (!g_PersonalNames[civ] || !g_PersonalNames[civ][gender])
        return null;

    const availableNames = g_PersonalNames[civ][gender];
    const usedNames = g_UsedPersonalNames[civ][gender];

    // Filter out already used names
    const unusedNames = availableNames.filter(name => usedNames.indexOf(name) === -1);

    if (unusedNames.length === 0)
        return null;

    // Select first available name (deterministic order)
    const selectedName = unusedNames[0];
    usedNames.push(selectedName);

    return selectedName;
}
